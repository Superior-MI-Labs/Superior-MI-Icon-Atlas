# Royal Forge UI Controls — Wave 2 candidate

**Import ZIP:** `Fantasy-RPG-HUD-Wave2-Royal-Forge-Controls-Candidate.zip`

Open https://superior-mi-labs.github.io/Superior-MI-Icon-Atlas/builder.html, use private ZIP import, and select the new Royal Forge composition and state sets. The ZIP holds one `smi-visual-collection/1` index, one `smi-visual-pack/1` manifest, and two true-alpha texture sheets. It is not published in the public catalog.

## Contents

- **214 addressable assets** — 152 regions, 32 state sets, 28 compositions, 2 sequences.
- **156 newly authored manifest assets**, including 108 independently rendered original SVG texture regions.
- Core button types: danger, accept, arcane, night, compact, and ruby/aqua/jade round buttons, plus inherited primary/secondary/icon controls.
- Switches/toggles/checkboxes/radio controls, directional navigation, vertical tabs, steppers, three-way selector, discrete dials, horizontal/vertical scrollbars, status badges, panel chrome, decorative trim, and highlight animation.
- Existing Wave 2 content remains: inventory and hotbar states, panel/tooltip examples, and the first UI controls.
- Buttons and toggles declare `behavior` events. Direct hit-testing and keyboard/gamepad interactions still require a game/host adapter.

## QA status

**Independent** ZIP integrity, reference graph, alpha/rectangle/non-overlap, full 152-region contact-sheet, 124 state samples, five sequence transition and 30 creator-specific acceptance checks: PASS after one corrective iteration. The 10 inherited inventory/hotbar edge-touch crops are review warnings. See `qa/qa-report.json` and the contact sheets in the separate source/evidence archive.

**NOT RUN:** Official repo ZIP validator, official repo creator acceptance runner, live Visual Atlas builder reimport/export and Chromium visual-state matrix. Do not claim public-release approval based on this preview package. Creator visual approval is outstanding.
