# Production learnings for the Visual Atlas repository

## Incident: a structurally valid but visually misleading disabled state

**Observed:** The inherited `checkbox.square.states` mapped `unchecked` and `disabled` to distinct asset IDs and valid coordinates, yet their actual crop pixels were exactly identical. A manifest validator cannot detect this.

**Fix:** Regenerate only the disabled image appearance, preserve its stable address, and update the owning texture checksum. Compare every original crop to the previous candidate to prove no other original asset changed. The disabled state now renders grayscale and visibly dimmed.

**Recommend adding to shared QA:** For each `state_set`, render all named states and compare them against the authored baseline with a perceptual threshold at the intended preview size. Flag exact duplicates and low-contrast variants; capture contact sheets. A duplicate can be intentional only with explicit author evidence. Add at least one negative regression in CI with two identical-state fixtures. This should be part of the central visual QA gate, not a new renderer or per-pack workaround.

## Rendering and UX observations

- The current manifest's `behavior` is declarative. A host must implement pointer capture, keyboard/gamepad focus, click dispatch and accessibility. Never call the control "fully interactive" merely because its event map exists.
- Control assets should be split into a visible `state_set` and thin `composition`, never four overlapping PNGs hidden under custom logic.
- Any value-bearing slider/scroll track must have one measured usable interval. The 268px tracks and 84px thumbs in this pack produce a 184px travel range, with native output values normalized by the existing renderer.
- Every state crop should have alpha padding. The inherited inventory/hotbar edge-touch warnings demonstrate why `PNG valid` and `no region overlap` are not sufficient to prove presentation quality.
- Prefer one cohesive pack over dozens of unrelated half-complete packs. Existing IDs and manifest schema must not be rewritten to make the catalog look better.

## Follow-up repo integration gates

1. Run the official `tools/validate_visual_pack.py` against the final ZIP.
2. Run the official strict contact-sheet qualifier and creator-specific acceptance fixture included in `qa/creator-acceptance.json`.
3. Preview every state in the actual builder, with screenshots, at the target scale.
4. Run Chromium state-change tests and mouse/keyboard host integration tests separately; confirm numeric scroll endpoints and reversible on/off behavior.
5. Export the final ZIP through the builder and reimport, comparing a fixed asset/state and pixel hash.
6. Only then commit approved runtime art under `examples/`, source under `production/`, and append `publications.json`; GitHub Pages publication is a separate approval decision.
