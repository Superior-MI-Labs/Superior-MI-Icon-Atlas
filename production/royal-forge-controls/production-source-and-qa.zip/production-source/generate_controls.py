#!/usr/bin/env python3
"""Royal Forge controls extension: authored SVG primitives -> measured regions -> portable Visual Atlas ZIP.

The source-of-truth is this generator plus the already-authored original Wave 2
candidate. This program never modifies existing IDs or texture bytes.
"""
from __future__ import annotations
import io,json,zipfile,hashlib,math,random,sys
from pathlib import Path
from collections import Counter
from xml.sax.saxutils import escape
from PIL import Image,ImageDraw,ImageFont
import cairosvg

ROOT=Path(__file__).resolve().parents[1]
SRC=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'production-source/base/Fantasy-RPG-HUD-Wave2-Candidate-Import-Verified.zip'
OUTPUT=ROOT/'Fantasy-RPG-HUD-Wave2-Royal-Forge-Controls-Candidate.zip'
PREFIX='smi.ui.fantasy01.wave2'
STYLE='fantasy-ornate-gold'
ATLAS_W,ATLAS_H=2048,1280
GAP=8
parts=[]
new_assets=[]
IDs=set()
SUBJECTS={
 'button':'ui.controls.buttons','round':'ui.controls.buttons','arrow':'ui.navigation.arrows',
 'toggle':'ui.controls.switches','checkbox':'ui.controls.checkboxes','radio':'ui.controls.radio',
 'segment':'ui.controls.selectors','stepper':'ui.controls.steppers',
 'scroll':'ui.controls.scrollbars','dial':'ui.controls.dials','tab':'ui.navigation.tabs',
 'badge':'ui.status.indicators','trim':'ui.panels.trim','panel':'ui.panels.frames','effect':'ui.effects.illumination'
}
PALETTE={
 'crimson':('#e24b64','#78213d','#ffbdbe'),
 'sapphire':('#4ecbfa','#154a82','#d3f6ff'),
 'emerald':('#57e1af','#126e56','#d2ffdf'),
 'amethyst':('#c8a1ff','#4e2889','#f1e2ff'),
 'amber':('#ffd078','#895226','#fff1b6'),
 'obsidian':('#95a5c5','#293453','#e2e9ff'),
 'gold':('#f2c76e','#7e5429','#fff4c4')
}
GOLD='#d6a861'; HIGHLIGHT='#fff0be'; DARK='#101525'

def root(w,h,body,accent='sapphire',state='default'):
    bright,deep,light=PALETTE[accent]
    if state=='disabled':bright,deep,light='#647082','#2b303b','#8996a5'
    if state=='pressed':deep='#101622'
    defs=f'''<defs>
    <linearGradient id="metal" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#fff1b0"/><stop offset=".17" stop-color="#c99c53"/><stop offset=".48" stop-color="#7b4828"/><stop offset=".78" stop-color="#efca7f"/><stop offset="1" stop-color="#765022"/></linearGradient>
    <linearGradient id="enamel" x1="0" y1="0" x2="0" y2="1"><stop stop-color="{light}"/><stop offset=".08" stop-color="{bright}"/><stop offset=".48" stop-color="{deep}"/><stop offset="1" stop-color="#111522"/></linearGradient>
    <linearGradient id="shadow" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#283049"/><stop offset=".53" stop-color="#111421"/><stop offset="1" stop-color="#080b12"/></linearGradient>
    <radialGradient id="gem"><stop stop-color="{light}"/><stop offset=".44" stop-color="{bright}"/><stop offset=".84" stop-color="{deep}"/><stop offset="1" stop-color="#10121e"/></radialGradient>
    <linearGradient id="shine" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#ffffff" stop-opacity=".56"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></linearGradient>
    <filter id="glow" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="2.1"/></filter>
    </defs>'''
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">{defs}{body}</svg>'

def jewel(x,y,r=6,col='url(#gem)'):
    return (f'<circle cx="{x}" cy="{y}" r="{r+1.5}" fill="#171020" stroke="{GOLD}" stroke-width="1.6"/>'
            f'<path d="M {x} {y-r} L {x+r*.85} {y} L {x} {y+r} L {x-r*.85} {y} Z" fill="{col}" stroke="{HIGHLIGHT}" stroke-width=".6"/>'
            f'<path d="M {x-r*.5} {y-1} L {x} {y-r*.58} L {x+r*.25} {y-1}" fill="none" stroke="#fff9de" stroke-opacity=".65" stroke-width=".8"/>')

def flourish(w,h):
    return (f'<path d="M 20 {h*.48} Q {w*.18} {h*.2} {w*.25} {h*.5} Q {w*.3} {h*.7} {w*.35} {h*.5}" fill="none" stroke="{GOLD}" stroke-width="1" opacity=".35"/>'
            f'<path d="M {w-20} {h*.48} Q {w*.82} {h*.2} {w*.75} {h*.5} Q {w*.7} {h*.7} {w*.65} {h*.5}" fill="none" stroke="{GOLD}" stroke-width="1" opacity=".35"/>')

def plate(w,h,accent='crimson',state='default',central=True):
    outer=('#e7cb91' if state=='hover' else GOLD if state!='disabled' else '#6c6f75')
    dx=1.5 if state=='pressed' else 0
    a=(f'<rect x="5" y="5" width="{w-10}" height="{h-10}" rx="{min(14,h*.21)}" fill="#050812" stroke="#49351b" stroke-width="2"/>'
       f'<rect x="6.5" y="6.5" width="{w-13}" height="{h-13}" rx="{min(12,h*.19)}" fill="url(#metal)" stroke="{outer}" stroke-width="2"/>'
       f'<rect x="10" y="10" width="{w-20}" height="{h-20}" rx="{min(9,h*.15)}" fill="url(#shadow)" stroke="#251c22" stroke-width="2"/>'
       f'<rect x="12" y="12" width="{w-24}" height="{h-24}" rx="{min(8,h*.13)}" fill="url(#enamel)" stroke="#f7dba0" stroke-opacity=".66" stroke-width="1.1"/>'
       f'<path d="M 17 15 H {w-17} V {h*.42} Q {w/2} {h*.29} 17 {h*.42} Z" fill="url(#shine)" opacity="{.57 if state=='hover' else .32 if state=='default' else .16}"/>'
       f'<path d="M 15 {h-14} Q {w/2} {h-9} {w-15} {h-14}" fill="none" stroke="#fff2be" stroke-width="1.2" opacity=".35"/>')
    if state=='hover':a+=f'<rect x="9" y="9" width="{w-18}" height="{h-18}" rx="9" fill="none" stroke="#e6faff" stroke-width="2.5" opacity=".65"/>'
    if state=='pressed':a+=f'<rect x="11" y="12" width="{w-22}" height="{h-25}" rx="8" fill="#050810" opacity=".3"/>'
    for px in (15,w-15):
        a+=jewel(px,h/2,3.2)
    if central:
        a+=flourish(w,h)+jewel(w/2,h/2+dx,9 if h>=65 else 6.5)
    if state=='disabled':a+=f'<rect x="12" y="12" width="{w-24}" height="{h-24}" rx="8" fill="#171b23" opacity=".55"/>'
    return a

def round_button(w,h,accent='sapphire',state='default'):
    x=w/2;y=h/2;r=min(w,h)/2-6
    a=(f'<circle cx="{x}" cy="{y}" r="{r+1}" fill="#060910" stroke="#75502a" stroke-width="2.5"/>'
       f'<circle cx="{x}" cy="{y}" r="{r-1}" fill="url(#metal)" stroke="#ffefc2" stroke-width="1.6"/>'
       f'<circle cx="{x}" cy="{y}" r="{r-5}" fill="url(#shadow)" stroke="#5a3c27" stroke-width="2"/>'
       f'<circle cx="{x}" cy="{y}" r="{r-8}" fill="url(#gem)" stroke="#f4d890" stroke-width="1.2"/>'
       f'<path d="M {x-r*.65} {y-r*.22} Q {x} {y-r*.95} {x+r*.64} {y-r*.22}" fill="none" stroke="#fff" opacity=".5" stroke-width="2"/>')
    if state=='hover':a+=f'<circle cx="{x}" cy="{y}" r="{r-3}" fill="none" stroke="#ffefd0" opacity=".8" stroke-width="3"/>'
    if state=='pressed':a+=f'<circle cx="{x}" cy="{y}" r="{r-9}" fill="#04060d" opacity=".4"/>'
    if state=='disabled':a+=f'<circle cx="{x}" cy="{y}" r="{r-8}" fill="#151920" opacity=".68"/>'
    return a

def arrow(w,h,direction='right',state='default'):
    base=round_button(w,h,'sapphire',state)
    pts={'up':[(w*.5,h*.3),(w*.72,h*.64),(w*.28,h*.64)],'down':[(w*.5,h*.7),(w*.72,h*.36),(w*.28,h*.36)],'left':[(w*.3,h*.5),(w*.67,h*.26),(w*.67,h*.74)],'right':[(w*.7,h*.5),(w*.33,h*.26),(w*.33,h*.74)]}[direction]
    points=' '.join(f'{x:.1f},{y:.1f}' for x,y in pts)
    return base+f'<polygon points="{points}" fill="#f9edc5" stroke="#55351c" stroke-width="2" stroke-linejoin="round"/>'

def switch(w,h,on=False,accent='emerald',disabled=False,lever=False):
    a=(f'<rect x="7" y="11" width="{w-14}" height="{h-22}" rx="{(h-22)/2}" fill="#080d19" stroke="url(#metal)" stroke-width="3"/>'
       f'<rect x="13" y="17" width="{w-26}" height="{h-34}" rx="{(h-34)/2}" fill="url(#shadow)" stroke="#d4a965" stroke-opacity=".65"/>'
       f'<rect x="18" y="22" width="{w-36}" height="{h-44}" rx="{(h-44)/2}" fill="{PALETTE[accent][1] if on else "#1a1e2b"}" opacity=".85"/>')
    xx=(w-h/2+2 if on else h/2-2);yy=h/2
    a+=f'<circle cx="{xx}" cy="{yy}" r="{h*.34}" fill="url(#metal)" stroke="#fff2bf" stroke-width="1.4"/>'
    a+=f'<circle cx="{xx}" cy="{yy}" r="{h*.27}" fill="url(#gem)" stroke="#392b26" stroke-width="1.7"/>'
    a+=f'<ellipse cx="{xx-h*.08}" cy="{yy-h*.12}" rx="{h*.095}" ry="{h*.07}" fill="#fff" opacity=".55"/>'
    if lever:a+=f'<path d="M {xx} {yy+4} L {xx + (12 if on else -12)} {yy-14}" stroke="#fff4bc" stroke-width="3.5" stroke-linecap="round"/>'
    if disabled:a+=f'<rect x="8" y="12" width="{w-16}" height="{h-24}" rx="{h*.3}" fill="#2a2c33" opacity=".62"/>'
    return a

def checkbox(w,h,mode='unchecked'):
    a=plate(w,h,'amethyst' if mode=='checked' else 'obsidian',('disabled' if mode=='disabled' else 'hover' if mode=='hover' else 'default'),False)
    a+=f'<path d="M {w/2} 16 L {w-16} {h/2} L {w/2} {h-16} L 16 {h/2} Z" fill="url(#shadow)" stroke="{GOLD}" stroke-width="1.8"/>'
    if mode=='checked':a+=f'<path d="M {w*.29} {h*.51} L {w*.45} {h*.67} L {w*.72} {h*.34}" fill="none" stroke="#80ffd7" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>'
    return a

def radio(w,h,mode='unselected'):
    a=round_button(w,h,'amethyst' if mode=='selected' else 'obsidian', 'disabled' if mode=='disabled' else 'default')
    if mode=='selected':a+=jewel(w/2,h/2,9)
    else:a+=f'<circle cx="{w/2}" cy="{h/2}" r="10" fill="#0c1020" stroke="#b3a27b" stroke-width="1.5"/>'
    return a

def segmented(w,h,index=0):
    a=plate(w,h,'sapphire','default',False)
    cell=(w-24)/3
    for i in range(3):
        px=12+i*cell
        a+=f'<rect x="{px:.2f}" y="13" width="{cell:.2f}" height="{h-26}" rx="5" fill="{"url(#enamel)" if i==index else "#101726"}" stroke="{GOLD}" stroke-width="1"/>'
        if i==index:a+=jewel(px+cell/2,h/2,7)
        else:a+=f'<circle cx="{px+cell/2}" cy="{h/2}" r="4" fill="#67718f"/>'
    return a

def tab(w,h,mode='default'):
    accent='amethyst' if mode=='selected' else 'sapphire'
    a=plate(w,h,accent,'disabled' if mode=='disabled' else 'hover' if mode=='hover' else 'default',True)
    if mode=='selected':a+=f'<rect x="{w-13}" y="16" width="4" height="{h-32}" rx="2" fill="#ffffb2"/>'
    return a

def scrollbar(w,h,vertical=True,part='track'):
    if part=='track':
        return (f'<rect x="5" y="5" width="{w-10}" height="{h-10}" rx="10" fill="url(#metal)" stroke="#ffe5b2" stroke-width="1.5"/>'
                f'<rect x="9" y="9" width="{w-18}" height="{h-18}" rx="7" fill="url(#shadow)" stroke="#88633e" stroke-width="1"/>')
    a=plate(w,h,'sapphire','default',False)
    for i in (-1,0,1):
        if vertical:a+=f'<path d="M {w*.28} {h/2+i*10} H {w*.72}" stroke="#f6d48b" stroke-width="2"/>'
        else:a+=f'<path d="M {w/2+i*10} {h*.28} V {h*.72}" stroke="#f6d48b" stroke-width="2"/>'
    return a

def stepper(w,h,sign='plus',state='default'):
    a=round_button(w,h,'amber',state)
    cx=w/2;cy=h/2
    a+=f'<path d="M {cx-12} {cy} H {cx+12}" stroke="#fff0bd" stroke-width="4" stroke-linecap="round"/>'
    if sign=='plus':a+=f'<path d="M {cx} {cy-12} V {cy+12}" stroke="#fff0bd" stroke-width="4" stroke-linecap="round"/>'
    return a

def dial(w,h,position=0,accent='amethyst'):
    a=round_button(w,h,accent,'default')
    cx=w/2;cy=h/2;r=min(w,h)*.34
    for j in range(11):
        th=math.radians(140-j*28)
        x1=cx+math.cos(th)*r*.82;y1=cy-math.sin(th)*r*.82
        x2=cx+math.cos(th)*r*.99;y2=cy-math.sin(th)*r*.99
        a+=f'<path d="M {x1:.2f} {y1:.2f} L {x2:.2f} {y2:.2f}" stroke="#fae9bd" stroke-width="{2 if j%5==0 else 1}"/>'
    th=math.radians(140-position*2.8)
    x=cx+math.cos(th)*r*.66;y=cy-math.sin(th)*r*.66
    a+=f'<path d="M {cx} {cy} L {x:.2f} {y:.2f}" stroke="#fff1ae" stroke-width="5" stroke-linecap="round"/>'
    a+=jewel(cx,cy,6)
    return a

def badge(w,h,name):
    a=round_button(w,h,{'warning':'crimson','success':'emerald','alert':'amber','quest':'amethyst','magic':'sapphire','lock':'obsidian'}[name],'default')
    cx=w/2;cy=h/2
    if name in ('warning','alert'):
        a+=f'<path d="M {cx} {cy-13} V {cy+3}" stroke="#ffedaf" stroke-width="5" stroke-linecap="round"/><circle cx="{cx}" cy="{cy+13}" r="3" fill="#ffedaf"/>'
    elif name=='success':a+=f'<path d="M {cx-14} {cy} L {cx-4} {cy+10} L {cx+15} {cy-12}" fill="none" stroke="#fff3d0" stroke-width="4.2" stroke-linecap="round" stroke-linejoin="round"/>'
    elif name=='quest':a+=jewel(cx,cy,13)
    elif name=='magic':a+=f'<path d="M {cx-3} {cy-16} L {cx+10} {cy-2} L {cx+2} {cy+2} L {cx+8} {cy+16} L {cx-10} {cy+1} L {cx-2} {cy-4} Z" fill="#fff1bd" stroke="#684c85" stroke-width="1"/>'
    else:a+=f'<rect x="{cx-11}" y="{cy-2}" width="22" height="20" rx="3" fill="#c19b63" stroke="#fff0ae" stroke-width="2"/><path d="M {cx-7} {cy-3} V {cy-9} A 7 7 0 0 1 {cx+7} {cy-9} V {cy-3}" fill="none" stroke="#fff0ae" stroke-width="3"/>'
    return a

def ornament(w,h,kind='corner'):
    a=''
    if kind.startswith('corner'):
        a+=f'<path d="M 7 {h-9} L 7 12 Q 7 7 13 7 H {w-10}" fill="none" stroke="url(#metal)" stroke-width="7" stroke-linecap="round"/>'
        a+=f'<path d="M 10 {h-10} L 10 15 Q 10 10 16 10 H {w-10}" fill="none" stroke="#ffe4ab" stroke-width="1.6"/>'
        a+=jewel(13,13,5)
        if 'right' in kind:a=f'<g transform="translate({w},0) scale(-1,1)">{a}</g>'
        if 'bottom' in kind:a=f'<g transform="translate(0,{h}) scale(1,-1)">{a}</g>'
    elif kind=='divider':
        a+=f'<path d="M 9 {h/2} H {w-9}" stroke="url(#metal)" stroke-width="5"/><path d="M 9 {h/2-2} H {w-9}" stroke="#ffedaf" stroke-width="1"/>'
        a+=jewel(w/2,h/2,6)
    elif kind=='header':a=plate(w,h,'amethyst','default',False)+flourish(w,h)
    elif kind=='panel':a=plate(w,h,'obsidian','default',False)
    return a

def pulse(w,h,frame=0):
    cx=w/2;cy=h/2;r=9+frame*4
    a=f'<circle cx="{cx}" cy="{cy}" r="{r+6}" fill="url(#gem)" opacity="{.24+frame*.09}" filter="url(#glow)"/>'
    a+=f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="none" stroke="#ffeac4" stroke-width="{2.5-frame*.4}" opacity="{.8-frame*.17}"/>'
    a+=jewel(cx,cy,7)
    return a

def add(name,w,h,svg_body,accent='sapphire',state='default',tags=(),subjects=(),desc=''):
    ident=f'{PREFIX}.{name}'
    if ident in IDs:raise ValueError('duplicate '+ident)
    IDs.add(ident)
    svg=root(w,h,svg_body,accent,state)
    data=cairosvg.svg2png(bytestring=svg.encode(),output_width=w,output_height=h)
    img=Image.open(io.BytesIO(data)).convert('RGBA')
    alpha=img.getchannel('A');bounds=alpha.getbbox()
    if bounds is None:raise ValueError('blank '+ident)
    if bounds[0]<3 or bounds[1]<3 or bounds[2]>w-2 or bounds[3]>h-2:raise ValueError('edge contact '+ident+' '+str(bounds))
    (ROOT/'production-source'/'svg'/f'{name}.svg').write_text(svg,encoding='utf-8')
    prefix=name.split('.')[0];meaning=SUBJECTS.get(prefix,'ui.controls')
    words=list(dict.fromkeys([prefix,*name.split('.'),*tags,'fantasy','game-ui','ornate','gold']))
    subject=list(dict.fromkeys([meaning,*subjects]))
    a={'id':ident,'kind':'region','name':name.replace('.',' ').replace('-',' ').title(),
       'texture':'atlas1','rect_px':None,'tags':words,'subjects':subject,
       'style':STYLE,'description':desc or 'Original Royal Forge fantasy game interface asset.'}
    new_assets.append(a);parts.append((a,img))
    return ident

def state_set(name,mapping,default,keywords=(),meaning=None):
    ident=f'{PREFIX}.{name}.states';assert ident not in IDs;IDs.add(ident)
    new_assets.append({'id':ident,'kind':'state_set','name':name.replace('.',' ').title()+' States',
      'states':mapping,'default_state':default,'style':STYLE,
      'tags':list(dict.fromkeys([*name.split('.'),'states',*keywords,'fantasy','game-ui'])),
      'subjects':[meaning or SUBJECTS.get(name.split('.')[0],'ui.controls')]})
    return ident

def component(name,title,size,layers,inputs=None,behavior=None,tags=(),subject='ui.controls',notes=''):
    ident=f'{PREFIX}.widget.{name}';assert ident not in IDs;IDs.add(ident)
    a={'id':ident,'kind':'composition','name':title,'size_px':list(size),'layers':layers,
       'tags':list(dict.fromkeys([*name.split('.'),*tags,'interactive','fantasy','rpg'])),
       'subjects':[subject],'style':STYLE}
    if inputs:a['inputs']=inputs
    if behavior:a['behavior']=behavior
    if notes:a['description']=notes
    new_assets.append(a)
    return ident

def button_behavior():
    return {'role':'button','outputs':{'state':{'from_input':'state'}},'on':{
      'pointer_enter':[{'op':'set','input':'state','value':'hover'}],
      'pointer_leave':[{'op':'set','input':'state','value':'default'}],
      'pointer_down':[{'op':'set','input':'state','value':'pressed'}],
      'pointer_up':[{'op':'set','input':'state','value':'hover'},{'op':'emit','event':'activated'}]}}

def button_composition(family,size,states):
    component(f'button-{family}',family.title()+' Action Button',size,[{'id':'plate','asset':states,'state_from_input':'state'}],
              inputs={'state':{'type':'enum','default':'default','values':['default','hover','pressed','disabled']}},
              behavior=button_behavior(),tags=['button','activate','hover','pressed','disabled',family],subject='ui.controls.buttons')

def toggler(name,size,off,on):
    component(name,name.replace('-',' ').title(),size,[
      {'id':'off','asset':off,'visible_when':{'input':'enabled','equals':False}},
      {'id':'on','asset':on,'visible_when':{'input':'enabled','equals':True}}],
      inputs={'enabled':{'type':'boolean','default':False}},
      behavior={'role':'toggle','outputs':{'enabled':{'from_input':'enabled'}},'on':{
      'activate':[{'op':'toggle','input':'enabled'},{'op':'emit','event':'changed'}]}},
      tags=['toggle','on','off','boolean'],subject='ui.controls.switches')

def build_new():
    # Five plate families with four fully authored visible states.
    for family,accent,size in [('danger','crimson',(248,64)),('accept','emerald',(248,64)),
                               ('arcane','amethyst',(248,64)),('night','obsidian',(248,64)),
                               ('compact','amber',(160,54))]:
        mapping={}
        for state in ('default','hover','pressed','disabled'):
            mapping[state]=add(f'button.{family}.{state}',*size,plate(*size,accent,state,True),accent,state,tags=['button',family,state])
        states=state_set('button.'+family,mapping,'default',meaning='ui.controls.buttons')
        button_composition(family,size,states)
    # Jewel buttons are useful as embedded inventory/action affordances.
    for family,accent in [('ruby','crimson'),('aqua','sapphire'),('jade','emerald')]:
        mapping={}
        for state in ('default','hover','pressed','disabled'):
            mapping[state]=add(f'round.{family}.{state}',72,72,round_button(72,72,accent,state),accent,state,tags=['circle','button',family,state])
        states=state_set('round.'+family,mapping,'default',meaning='ui.controls.buttons')
        button_composition(f'round-{family}',(72,72),states)
    # Directional nav buttons are independent assets and complete selectable family.
    for direction in ('up','down','left','right'):
        mapping={}
        for state in ('default','hover','pressed','disabled'):
            mapping[state]=add(f'arrow.{direction}.{state}',66,66,arrow(66,66,direction,state),'sapphire',state,tags=['navigation','chevron',direction,state])
        states=state_set('arrow.'+direction,mapping,'default',meaning='ui.navigation.arrows')
        component('arrow-'+direction,direction.title()+' Navigation Button',(66,66),[{'id':'body','asset':states,'state_from_input':'state'}],
          inputs={'state':{'type':'enum','default':'default','values':['default','hover','pressed','disabled']}},
          behavior=button_behavior(),tags=['navigation','arrow',direction],subject='ui.navigation.arrows')
    # Lever and jewel switches: mechanical silhouette differs from existing switch.
    for family,accent in [('lever','amber'),('jewel','amethyst')]:
        mapping={}
        for state in ('off','on','disabled'):
            mapping[state]=add(f'toggle.{family}.{state}',168,68,switch(168,68,state=='on',accent,state=='disabled',family=='lever'),accent,state,tags=['switch',family,state])
        state_set('toggle.'+family,mapping,'off',meaning='ui.controls.switches')
        toggler(f'toggle-{family}',(168,68),mapping['off'],mapping['on'])
    # Checkboxes / radios with explicit checked and disabled variants.
    for name,states,func in [
       ('checkbox.diamond',['unchecked','checked','hover','disabled'],checkbox),
       ('radio.gem',['unselected','selected','disabled'],radio)]:
        mapping={}
        for state in states:
            mapping[state]=add(f'{name}.{state}',72,72,func(72,72,state),'amethyst',state,tags=[name.split('.')[0],state])
        state_set(name,mapping,states[0])
        off=mapping['unchecked'] if 'unchecked' in mapping else mapping['unselected']
        on=mapping['checked'] if 'checked' in mapping else mapping['selected']
        toggler(name.replace('.','-'),(72,72),off,on)
    # Segmented, 3-position selector (no invented pointer interactions).
    segment_ids={}
    for idx,label in enumerate(('left','center','right')):
        segment_ids[label]=add(f'segment.royal.{label}',216,64,segmented(216,64,idx),'sapphire','default',tags=['three-way','selector',label])
    states=state_set('segment.royal',segment_ids,'left',meaning='ui.controls.selectors')
    component('segment-royal','Three-Way Royal Selector',(216,64),[
      {'id':'segments','asset':states,'state_from_input':'selected'}],
      inputs={'selected':{'type':'enum','default':'left','values':['left','center','right']}},
      behavior={'role':'select','outputs':{'selected':{'from_input':'selected'}},'on':{
        'set_selected':[{'op':'set','input':'selected','source':'event.value'},{'op':'emit','event':'selection_changed'}]}},
      tags=['segmented','three-way','navigation','select'],subject='ui.controls.selectors')
    # Alternative vertical tabs, preserving 4 exact distinct states.
    mapping={}
    for state in ('default','hover','selected','disabled'):
        mapping[state]=add(f'tab.vertical.{state}',104,152,tab(104,152,state),'sapphire',state,tags=['tab','vertical',state])
    states=state_set('tab.vertical',mapping,'default',meaning='ui.navigation.tabs')
    component('tab-vertical','Vertical Royal Navigation Tab',(104,152),[{'id':'tab','asset':states,'state_from_input':'selection'}],
      inputs={'selection':{'type':'enum','default':'default','values':['default','hover','selected','disabled']}},
      behavior={'role':'select','outputs':{'selection':{'from_input':'selection'}},'on':{
        'select_tab':[{'op':'set','input':'selection','source':'event.value'},{'op':'emit','event':'selected'}]}},
      tags=['vertical','tab','navigation','selected'],subject='ui.navigation.tabs')
    # Two scrollbar orientations, split into track and thumb for host positioning.
    for orientation in ('horizontal','vertical'):
        vertical=orientation=='vertical'
        track_size=(44,268) if vertical else (268,44)
        thumb_size=(44,84) if vertical else (84,44)
        track=add(f'scroll.{orientation}.track',*track_size,scrollbar(*track_size,vertical,'track'),'obsidian',tags=['scrollbar',orientation,'track'])
        thumb=add(f'scroll.{orientation}.thumb',*thumb_size,scrollbar(*thumb_size,vertical,'thumb'),'sapphire',tags=['scrollbar',orientation,'thumb'])
        axis='y' if vertical else 'x'
        component('scroll-'+orientation,orientation.title()+' Interactive Scrollbar',track_size,[
          {'id':'track','asset':track},
          {'id':'thumb','asset':thumb,'position_from_input':{'input':'value','axis':axis,'from_px':0,'to_px':184}}],
          inputs={'value':{'type':'number','default':50,'min':0,'max':100}},
          behavior={'role':'slider','outputs':{'value':{'from_input':'value','unit':'percent'}},'on':{
             'set_value':[{'op':'set','input':'value','source':'event.value'},{'op':'emit','event':'value_changed'}]}},
          tags=['scrollbar',orientation,'drag','thumb','scroll'],subject='ui.controls.scrollbars')
    # +/- controls, exact state-family support.
    for sign in ('plus','minus'):
        mapping={}
        for state in ('default','hover','pressed','disabled'):
            mapping[state]=add(f'stepper.{sign}.{state}',72,72,stepper(72,72,sign,state),'amber',state,tags=['increment' if sign=='plus' else 'decrement',sign,state])
        states=state_set('stepper.'+sign,mapping,'default')
        component('stepper-'+sign,sign.title()+' Stepper Action',(72,72),[{'id':'button','asset':states,'state_from_input':'state'}],
          inputs={'state':{'type':'enum','default':'default','values':['default','hover','pressed','disabled']}},
          behavior=button_behavior(),tags=['stepper','increment' if sign=='plus' else 'decrement',sign],subject='ui.controls.steppers')
    # Dial states in 0,25,50,75,100 increments; host apps can choose exact orientation.
    for dial_name,accent in [('arcane','amethyst'),('sunstone','amber')]:
        mapping={}
        for pos in (0,25,50,75,100):
            mapping[str(pos)]=add(f'dial.{dial_name}.{pos}',116,116,dial(116,116,pos,accent),accent,'default',tags=['knob','rotary','dial',str(pos)])
        state_set('dial.'+dial_name,mapping,'50',meaning='ui.controls.dials')
        component('dial-'+dial_name,dial_name.title()+' Rotary Dial',(116,116),[
          {'id':'knob','asset':f'{PREFIX}.dial.{dial_name}.states','state_from_input':'setting'}],
          inputs={'setting':{'type':'enum','default':'50','values':['0','25','50','75','100']}},
          behavior={'role':'select','outputs':{'setting':{'from_input':'setting'}},'on':{
             'set_setting':[{'op':'set','input':'setting','source':'event.value'},{'op':'emit','event':'setting_changed'}]}},
          tags=['dial','knob','value','discrete'],subject='ui.controls.dials')
    # Six feedback badges, three content panels and decorative source pieces.
    for name in ('warning','success','alert','quest','magic','lock'):
        add(f'badge.{name}',76,76,badge(76,76,name),'amber',tags=['notification','status',name])
    for name,size,kind in [
        ('trim.corner.top-left',(70,70),'corner'),('trim.corner.top-right',(70,70),'corner-right'),
        ('trim.corner.bottom-left',(70,70),'corner-bottom'),('trim.corner.bottom-right',(70,70),'corner-right-bottom'),
        ('trim.divider',(280,36),'divider'),
        ('panel.banner',(340,68),'header'),('panel.window',(360,264),'panel'),('panel.small',(260,164),'panel')]:
        add(name,*size,ornament(*size,kind),'obsidian',tags=['panel','frame','trim',name.split('.')[-1]])
    for frame in range(4):
        add(f'effect.highlight.frame{frame}',76,76,pulse(76,76,frame),'amber',tags=['effect','pulse','glow','frame'])
    new_assets.append({'id':f'{PREFIX}.effect.highlight.sequence','kind':'sequence','name':'Royal Highlight Pulse',
      'default_fps':8,'playback':'pingpong',
      'frames':[{'asset':f'{PREFIX}.effect.highlight.frame{i}'} for i in range(4)],
      'style':STYLE,'tags':['animation','highlight','pulse','glow'],'subjects':['ui.effects.illumination']})
    component('window-royal','Royal Interactive Window',(360,264),[
      {'id':'frame','asset':f'{PREFIX}.panel.window'},
      {'id':'header','asset':f'{PREFIX}.panel.banner','offset_px':[10,9],'size_px':[340,68]}],
      tags=['window','dialog','container','panel','frame'],subject='ui.panels.frames',
      notes='Nine-slice-free composed panel at its native authored size. Host handles layout and text.')


def pack():
    build_new()
    print('New assets',len(new_assets),'source parts',len(parts))
    atlas=Image.new('RGBA',(ATLAS_W,ATLAS_H),(0,0,0,0))
    x=y=row_h=GAP
    for a,img in parts:
        w,h=img.size
        if x+w+GAP>ATLAS_W:x=GAP;y+=row_h+GAP;row_h=0
        if y+h+GAP>ATLAS_H:raise ValueError('Atlas overflow at '+a['id'])
        atlas.alpha_composite(img,(x,y));a['rect_px']=[x,y,w,h]
        x+=w+GAP;row_h=max(row_h,h)
    texture=io.BytesIO();atlas.save(texture,format='PNG',optimize=True);texbytes=texture.getvalue()
    with zipfile.ZipFile(SRC) as z:
        manifest=json.loads(z.read('manifest.json'))
        collection=json.loads(z.read('collection.json'))
        original={name:z.read(name) for name in z.namelist() if name.startswith('textures/')}
    # Correct one existing candidate defect at source: unchecked and disabled were
    # pixel-identical. Keep the stable region ID/rectangle; replace only those pixels.
    disabled_id=f'{PREFIX}.checkbox.square.disabled'
    disabled=next(a for a in manifest['assets'] if a['id']==disabled_id)
    source_key=manifest['textures'][disabled['texture']]['path']
    existing=Image.open(io.BytesIO(original[source_key])).convert('RGBA')
    x0,y0,w0,h0=disabled['rect_px']
    region=existing.crop((x0,y0,x0+w0,y0+h0))
    from PIL import ImageEnhance
    alpha=region.getchannel('A')
    region=ImageEnhance.Color(region).enhance(.04)
    region=ImageEnhance.Brightness(region).enhance(.57)
    region.putalpha(alpha)
    existing.paste(region,(x0,y0))
    rebuilt=io.BytesIO();existing.save(rebuilt,format='PNG',optimize=True)
    original[source_key]=rebuilt.getvalue()
    manifest['textures'][disabled['texture']]['sha256']=hashlib.sha256(original[source_key]).hexdigest()
    original_assets=manifest['assets']
    existing={a['id'] for a in original_assets}
    assert not existing.intersection(IDs)
    manifest['textures']['atlas1']={'path':'textures/fantasy-controls-01.png','width_px':ATLAS_W,'height_px':ATLAS_H,'alpha':'straight','color_space':'srgb','sha256':hashlib.sha256(texbytes).hexdigest()}
    manifest['assets']=original_assets+new_assets
    manifest['version']='0.2.0'
    manifest['description']='Royal Forge core controls expansion: new buttons, switches, navigation, steppers, selectors, dials, scroll parts and panels; retains all original Wave 2 IDs.'
    collection['version']='0.2.0';collection['name']='Fantasy RPG HUD Wave 2 — Royal Forge Core Controls'
    collection['description']='Original fantasy RPG controls kit: per-state texture parts, interactive compositions, menus and chrome. Host handles pointer/keyboard navigation.'
    collection['entry_asset']=f'{PREFIX}.widget.button-arcane'
    # Do not include source SVGs inside the runtime ZIP. Source generator is provided separately.
    records={**original,'textures/fantasy-controls-01.png':texbytes,
      'manifest.json':(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n').encode(),
      'collection.json':(json.dumps(collection,indent=2,ensure_ascii=False)+'\n').encode(),
      'LICENSE.txt':b'CC0-1.0: Original Royal Forge SVG and source textures; attribution appreciated, not required. No third-party textures or embedded fonts.\n',
      'README.txt':b'Fantasy RPG HUD Wave 2 Royal Forge: import this ZIP directly into the local-first Visual Atlas Builder. 0.2.0 candidate. Pointer hit-testing and gamepad integration belong to host apps. Art direction, accessibility and in-game scaling need final review.\n'}
    with zipfile.ZipFile(OUTPUT,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
        for key in sorted(records):
            info=zipfile.ZipInfo(key,date_time=(2020,1,1,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=(0o644<<16)
            z.writestr(info,records[key],compress_type=zipfile.ZIP_DEFLATED,compresslevel=7)
    (ROOT/'qa'/'metadata.json').write_text(json.dumps({'pack':str(OUTPUT),'new_asset_count':len(new_assets),'new_region_count':len(parts),
       'total_asset_count':len(manifest['assets']),'kinds':dict(Counter(a['kind'] for a in manifest['assets'])),
       'textures':{k:list((v['width_px'],v['height_px'])) for k,v in manifest['textures'].items()},
       'sha256':hashlib.sha256(OUTPUT.read_bytes()).hexdigest()},indent=2))
    atlas.save(ROOT/'qa'/'new-atlas.png')
    print('Produced',OUTPUT,OUTPUT.stat().st_size,'bytes')
    return manifest,atlas

if __name__=='__main__':pack()
