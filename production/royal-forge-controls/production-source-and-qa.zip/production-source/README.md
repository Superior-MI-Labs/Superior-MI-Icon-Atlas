# Royal Forge — Fantasy RPG HUD Wave 2 (Core Controls)

This folder is the **editable source archive**, separate from the runtime ZIP. The original Wave 2 candidate is the immutable input except for the explicitly documented `checkbox.square.disabled` pixel repair; all 58 original asset definitions and IDs remain untouched. The extension contains 108 original SVG shapes authored in `svg/` and adds 156 new manifest assets.

## Rebuild

From a folder containing `production-source/` and `qa/`:

```bash
python3 -m pip install pillow cairosvg numpy
python3 production-source/generate_controls.py
python3 qa/qualify_pack.py
python3 qa/run_creator_checks.py
```

The runtime ZIP and QA evidence are generated into the parent directory. Original baseline ZIP: `production-source/base/Fantasy-RPG-HUD-Wave2-Candidate-Import-Verified.zip`. Do not distribute raw source artwork as part of the runtime import ZIP; raw SVGs belong here in the production archive.

## Source/manifest rules

- `smi-visual-pack/1` and `smi-visual-collection/1` only. No custom asset kind, renderer, or script in the manifest.
- Stable original 58 asset definitions and IDs are retained. The corrected bitmap is documented below.
- Original artwork is CC0-1.0. No imported fonts or third-party imagery.
- Two RGBA atlases: existing 2048×1024 and new 2048×1280, exact pixel rectangles and 8px packing gutters.
- Preserved typed host event names. Real keyboard, pointer, gamepad and input focus belong to the host adapter, not to texture metadata.
- `widget.scroll-horizontal` and `widget.scroll-vertical` use the 0–100 native range; thumb travel is exactly 184 px (268px track minus 84px thumb).

## Documented baseline art correction

The old `checkbox.square.unchecked` and `checkbox.square.disabled` were pixel-identical, so the disabled state was not observable. `generate_controls.py` desaturates/darkens only the original disabled region while preserving its original dimensions, alpha mask, region ID and rectangle. A regression test asserts this is the **only** changed original source region. Original texture SHA changes accordingly; manifest checksums are regenerated. This intentionally invalidates byte-for-byte preservation of the full original first texture and must not be silently represented as unchanged art.

## Known limitations

Ten original inventory/hotbar source regions touch the edge of their own declared region rectangles, although they do not overlap a neighbor. They remain flagged in the QA receipt for a future crop-geometry review; no automatic crop expansion or coordinate modification was applied.

No host-interaction adapter is embedded. The official repository validator, official creator acceptance runner, and Chromium builder import/re-export matrix were **not run** in this execution environment. The included independent acceptance script and geometry tests are supplemental evidence, not substitutes for the mandatory official release gates. This is an **import candidate for creator review**, not an approved public release.
