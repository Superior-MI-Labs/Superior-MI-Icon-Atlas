"""Independent local executor for repo-compatible creator acceptance predicates."""
import json,zipfile,sys,hashlib,io
from pathlib import Path
from PIL import Image
zpath=Path(__file__).resolve().parents[1]/'Fantasy-RPG-HUD-Wave2-Royal-Forge-Controls-Candidate.zip'
spec=json.loads((Path(__file__).parent/'creator-acceptance.json').read_text())
with zipfile.ZipFile(zpath) as z:
 pack=json.loads(z.read('manifest.json'));assets={a['id']:a for a in pack['assets']};failed=[]
 for i,c in enumerate(spec['checks'],1):
  a=assets.get(c['asset']);typ=c['type'];v=False
  if a:
   if typ=='asset_kind':v=a['kind']==c['kind']
   elif typ=='state_contains':v=c['state'] in a.get('states',{})
   elif typ=='input_declared':v=a.get('inputs',{}).get(c['input'],{}).get('type')==c['input_type']
   elif typ=='event_declared':v=c['event'] in a.get('behavior',{}).get('on',{})
   elif typ=='output_maps_from_input':v=a.get('behavior',{}).get('outputs',{}).get(c['output'],{}).get('from_input')==c['input']
   elif typ=='input_range':r=a.get('inputs',{}).get(c['input'],{});v=r.get('min')==c['min'] and r.get('max')==c['max']
   elif typ=='layer_order':ly=[l['id'] for l in a.get('layers',[])];v=c['before'] in ly and c['after'] in ly and ly.index(c['before'])<ly.index(c['after'])
   elif typ=='layer_uses_input':v=any(l.get('id')==c['layer'] and l.get(c['binding'],{}).get('input')==c['input'] for l in a.get('layers',[]))
   elif typ=='sequence_frames':v=len(a.get('frames',[]))>=c['at_least']
   elif typ=='sequence_distinct_frames':
    hashes=[]
    for f in a.get('frames',[]):
     region=assets[f['asset']];tex=pack['textures'][region['texture']]['path'];img=Image.open(io.BytesIO(z.read(tex))).convert('RGBA');x,y,w,h=region['rect_px'];hashes.append(hashlib.sha256(img.crop((x,y,x+w,y+h)).tobytes()).hexdigest())
    v=len(set(hashes))>=c['at_least']
   elif typ=='tag_contains':v=c['tag'] in a.get('tags',[])
  if not v:failed.append({'check':i,'type':typ,'asset':c['asset']})
 result={'schema':'smi-local-acceptance/1','checks':len(spec['checks']),'passed':len(spec['checks'])-len(failed),'failed':failed,'result':'PASS' if not failed else 'FAIL','runner':'Independent implementation of repository declarative predicates; official runner NOT RUN'}
 (Path(__file__).parent/'creator-acceptance-result.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,indent=2))
 assert not failed
