#!/usr/bin/env python3
"""Independent qualification of the complete handoff ZIP.
Does not claim to replace repository ZIP validator/Chromium builder testing.
"""
from __future__ import annotations
import hashlib,io,json,zipfile,math,statistics
from pathlib import Path
from collections import Counter,defaultdict
from PIL import Image,ImageDraw,ImageFont,ImageChops,ImageEnhance
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
ARCHIVE=ROOT/'Fantasy-RPG-HUD-Wave2-Royal-Forge-Controls-Candidate.zip'
OUT=ROOT/'qa'
OUT.mkdir(exist_ok=True)
font_path='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
font=ImageFont.truetype(font_path,14)
font_small=ImageFont.truetype(font_path,11)
errors=[];warnings=[]
with zipfile.ZipFile(ARCHIVE) as z:
    files=z.namelist();assert z.testzip() is None
    assert all(not f.startswith('/') and '..' not in Path(f).parts for f in files)
    m=json.loads(z.read('manifest.json'));coll=json.loads(z.read('collection.json'))
    textures={key:Image.open(io.BytesIO(z.read(spec['path']))).convert('RGBA') for key,spec in m['textures'].items()}
    original=ROOT/'production-source/base/Fantasy-RPG-HUD-Wave2-Candidate-Import-Verified.zip'
    with zipfile.ZipFile(original) as earlier:
        baseline=json.loads(earlier.read('manifest.json'))
        prev={a['id']:a for a in baseline['assets']}
        assert all(a in {x['id'] for x in m['assets']} for a in prev)
        assert all(next(x for x in m['assets'] if x['id']==k)==old for k,old in prev.items()),'Stable asset changed'
        # Exactly one known visual defect was repaired: an unchanged disabled checkbox.
        old_tex=Image.open(io.BytesIO(earlier.read('textures/fantasy-controls-00.png'))).convert('RGBA')
        new_tex=textures['atlas0']; changed_original=[]
        for a in baseline['assets']:
            if a['kind']!='region':continue
            x,y,w,h=a['rect_px']
            if old_tex.crop((x,y,x+w,y+h)).tobytes()!=new_tex.crop((x,y,x+w,y+h)).tobytes():changed_original.append(a['id'])
        assert changed_original==['smi.ui.fantasy01.wave2.checkbox.square.disabled'], 'Unexpected changed original regions: '+str(changed_original)

    for tex,spec in m['textures'].items():
        if textures[tex].size!=(spec['width_px'],spec['height_px']):errors.append('Wrong texture dimensions '+tex)
        if hashlib.sha256(z.read(spec['path'])).hexdigest()!=spec['sha256']:errors.append('Wrong texture sha '+tex)
    assets={a['id']:a for a in m['assets']}
    if len(assets)!=len(m['assets']):errors.append('Duplicate IDs')
    if coll['entry_asset'] not in assets:errors.append('Missing entry asset')
    expected_kinds={'region','composition','state_set','sequence'}
    kindcount=Counter(a['kind'] for a in assets.values())
    if set(kindcount)-expected_kinds:errors.append('Unsupported kinds')
    regions=defaultdict(list)
    crops={}
    for a in assets.values():
        if not a.get('tags'):warnings.append('No keywords '+a['id'])
        if a['kind']=='region':
            tex=a['texture'];x,y,w,h=a['rect_px']
            if tex not in textures or not(0<=x<textures[tex].width and 0<=y<textures[tex].height and w>0 and h>0 and x+w<=textures[tex].width and y+h<=textures[tex].height):errors.append('Invalid texture reference or crop '+a['id']);continue
            crop=textures[tex].crop((x,y,x+w,y+h));crops[a['id']]=crop
            if crop.getchannel('A').getbbox() is None:errors.append('Blank crop '+a['id'])
            bb=crop.getchannel('A').getbbox()
            if bb and min(bb[0],bb[1],w-bb[2],h-bb[3])<2:warnings.append('Edge-touch crop '+a['id'])
            regions[tex].append(a)
    for tex,arr in regions.items():
        for n,a in enumerate(arr):
            ax,ay,aw,ah=a['rect_px']
            for b in arr[n+1:]:
                bx,by,bw,bh=b['rect_px']
                if ax<bx+bw and bx<ax+aw and ay<by+bh and by<ay+ah:errors.append('Overlapping regions '+a['id']+' / '+b['id'])
    refs=defaultdict(list)
    for a in assets.values():
        ident=a['id'];kind=a['kind']
        if kind=='state_set':
            if a['default_state'] not in a['states']:errors.append('Bad default state '+ident)
            refs[ident]+=[*a['states'].values()]
        if kind=='sequence':
            refs[ident]+=[x['asset'] for x in a['frames']]
            if a['default_fps']<=0:errors.append('Bad FPS '+ident)
        if kind=='composition':
            if len(a.get('size_px',[]))!=2 or min(a['size_px'])<=0:errors.append('Bad canvas size '+ident)
            refs[ident]+=[x['asset'] for x in a['layers'] if 'asset' in x]
            for key,spec in a.get('inputs',{}).items():
                if spec['type']=='number' and not(spec['min']<spec['max'] and spec['min']<=spec['default']<=spec['max']):errors.append('Bad numeric range '+ident+'.'+key)
                if spec['type']=='enum' and spec['default'] not in spec['values']:errors.append('Bad enum '+ident+'.'+key)
            for layer in a['layers']:
                for prop in ('clip','position_from_input','state_from_input'):
                    binding=layer.get(prop)
                    input_key=binding if prop=='state_from_input' else binding.get('input') if isinstance(binding,dict) else None
                    if input_key and input_key not in a.get('inputs',{}):errors.append('Missing input binding '+ident+'.'+input_key)
            for actions in a.get('behavior',{}).get('on',{}).values():
                for action in actions:
                    if action['op'] in ('set','toggle') and action['input'] not in a.get('inputs',{}):errors.append('Bad action target '+ident)
        for k in refs[ident]:
            if k not in assets:errors.append('Missing dependency '+ident+' -> '+k)
    seen=set();active=set()
    def visit(ident):
        if ident in active:errors.append('Reference cycle at '+ident);return
        if ident in seen:return
        active.add(ident)
        for k in refs[ident]:
            if k in assets:visit(k)
        active.remove(ident);seen.add(ident)
    for ident in assets:visit(ident)
    def draw_asset(ident,state=None,inputs=None):
        a=assets[ident];kind=a['kind'];inputs=inputs or {}
        if kind=='region':return crops[ident].copy()
        if kind=='state_set':return draw_asset(a['states'][state or a['default_state']],inputs=inputs)
        if kind=='sequence':return draw_asset(a['frames'][0]['asset'],inputs=inputs)
        out=Image.new('RGBA',tuple(a['size_px']),(0,0,0,0))
        eff={k:inputs.get(k,s['default']) for k,s in a.get('inputs',{}).items()}
        for layer in a['layers']:
            cond=layer.get('visible_when')
            if cond and eff.get(cond['input'])!=cond['equals']:continue
            target=layer.get('asset')
            if not target:continue
            child=draw_asset(target,state=eff.get(layer.get('state_from_input')) if layer.get('state_from_input') else layer.get('state'),inputs=eff)
            if layer.get('size_px'):child=child.resize(tuple(layer['size_px']),Image.Resampling.LANCZOS)
            pos=list(layer.get('offset_px',[0,0]))
            if 'position_from_input' in layer:
                p=layer['position_from_input'];v=eff[p['input']];rng=a['inputs'][p['input']]
                f=max(0,min(1,(v-rng['min'])/(rng['max']-rng['min'])))
                pos[0 if p['axis']=='x' else 1]+=round(p['from_px']+f*(p['to_px']-p['from_px']))
            if 'clip' in layer:
                c=layer['clip'];v=eff[c['input']];rng=a['inputs'][c['input']]
                f=max(0,min(1,(v-rng['min'])/(rng['max']-rng['min'])))
                mask=Image.new('L',child.size,0);d=ImageDraw.Draw(mask)
                if c['axis']=='x':d.rectangle((0,0,round(f*child.width),child.height),fill=255)
                else:d.rectangle((0,round((1-f)*child.height),child.width,child.height),fill=255)
                alpha=ImageChops.multiply(child.getchannel('A'),mask);child.putalpha(alpha)
            if layer.get('opacity',1)<1:child.putalpha(child.getchannel('A').point(lambda x:round(x*layer['opacity'])))
            out.alpha_composite(child,dest=tuple(pos))
        return out

    # Inspect every state against the baseline state, including existing controls.
    state_changes={};state_previews={}
    for a in assets.values():
        if a['kind']!='state_set':continue
        baseline_img=draw_asset(a['id'],state=a['default_state'])
        for state in a['states']:
            test_img=draw_asset(a['id'],state=state)
            if test_img.size!=baseline_img.size:warnings.append('State sizes differ '+a['id']+' '+state);continue
            d=ImageChops.difference(baseline_img,test_img)
            changed=np.count_nonzero(np.any(np.asarray(d)>9,axis=2))
            state_changes[a['id']+'#'+state]=int(changed)
            if state!=a['default_state'] and changed<8:errors.append('Unobservable state change '+a['id']+'#'+state)
            state_previews[a['id']+'#'+state]=test_img
    frame_changes={}
    for a in assets.values():
        if a['kind']!='sequence':continue
        frames=[draw_asset(f['asset']) for f in a['frames']]
        for idx in range(len(frames)-1):
            if frames[idx].size!=frames[idx+1].size:errors.append('Sequence frame size change '+a['id'])
            else:
                changed=np.count_nonzero(np.any(np.asarray(ImageChops.difference(frames[idx],frames[idx+1]))>9,axis=2))
                frame_changes[a['id']+f'#{idx}-{idx+1}']=int(changed)
                if changed<8:errors.append('Indistinguishable animation frame '+a['id']+f'#{idx}')
    for a in assets.values():
        if a['kind']=='composition' and a.get('inputs'):
            for inp,rule in a['inputs'].items():
                if rule['type'] not in ('number','boolean','enum'):continue
                values=[rule['min'],(rule['min']+rule['max'])/2,rule['max']] if rule['type']=='number' else [False,True] if rule['type']=='boolean' else list(rule['values'])
                frames=[draw_asset(a['id'],inputs={inp:v}) for v in values]
                distinct=len({hashlib.sha256(im.tobytes()).hexdigest() for im in frames})
                if distinct<2:warnings.append('Input has no visible change '+a['id']+' '+inp)
    # Explicit scroll controls must travel exactly 184 px within 268px track.
    for direction in ['horizontal','vertical']:
        ident=f'smi.ui.fantasy01.wave2.widget.scroll-{direction}'
        imgs=[draw_asset(ident,inputs={'value':v}) for v in (0,1,5,10,25,50,75,90,99,100)]
        assert all(i.size==imgs[0].size for i in imgs)
        assert imgs[0].tobytes()!=imgs[-1].tobytes(),direction+' scrollbar must move'
    # Exact 152 region crops are included on pages, not one preview per sheet.
    region_items=[(a['id'],crops[a['id']]) for a in assets.values() if a['kind']=='region']
    def contact_sheet(items,name,cols=6,tw=194,th=138):
        nrows=math.ceil(len(items)/cols)
        page=Image.new('RGB',(cols*tw,nrows*th),(18,25,38))
        d=ImageDraw.Draw(page)
        for idx,(ident,img) in enumerate(items):
            col=idx%cols;row=idx//cols;x=col*tw;y=row*th
            d.rectangle((x+2,y+2,x+tw-3,y+th-3),fill=(25,35,52),outline=(80,92,113),width=1)
            avail=(tw-25,th-48)
            fac=min(avail[0]/img.width,avail[1]/img.height,1)
            preview=img.resize((max(1,int(img.width*fac)),max(1,int(img.height*fac))),Image.Resampling.LANCZOS)
            # checkerboard behind alpha
            bg=Image.new('RGBA',preview.size,(31,43,63,255));bg.alpha_composite(preview)
            page.paste(bg.convert('RGB'),(x+(tw-preview.width)//2,y+10+(th-48-preview.height)//2))
            title=ident.split('wave2.')[-1]
            lines=[title[:29],title[29:58]]
            for z,line in enumerate(lines):d.text((x+9,y+th-36+z*14),line,font=font_small,fill=(205,218,235))
        page.save(OUT/name)
    for idx in range(0,len(region_items),42):contact_sheet(region_items[idx:idx+42],f'contact-regions-{idx//42+1:02d}.png',6)
    preview_items=[(a['id'],draw_asset(a['id'])) for a in assets.values() if a['kind']=='composition']
    contact_sheet(preview_items,'contact-compositions.png',4,270,206)
    contact_sheet(list(state_previews.items())[:50],'contact-states-01.png',5,220,166)
    contact_sheet(list(state_previews.items())[50:],'contact-states-02.png',5,220,166)
    # Make a presentable curated cover showing actual rendered assets, not generated mood art.
    cover=Image.new('RGB',(1440,920),(13,20,32));d=ImageDraw.Draw(cover)
    d.rectangle((0,0,1440,100),fill=(22,31,47));d.text((57,26),'ROYAL FORGE',fill=(248,211,141),font=ImageFont.truetype(font_path,34));d.text((59,73),'FANTASY RPG  /  UI CONTROLS  /  WAVE 2',fill=(155,176,209),font=font)
    ids=['widget.button-arcane','widget.button-accept','widget.button-danger','widget.button-compact',
         'widget.toggle-lever','widget.toggle-jewel','widget.segment-royal',
         'widget.dial-arcane','widget.dial-sunstone','widget.scroll-horizontal',
         'widget.round-ruby','widget.round-aqua','widget.round-jade',
         'widget.tab-vertical','widget.window-royal','widget.checkbox-diamond',
         'widget.radio-gem','widget.arrow-right','widget.stepper-plus']
    locs=[(60,135),(355,135),(650,135),(990,135),
          (70,260),(345,260),(630,260),
          (965,255),(1150,255),(55,408),
          (430,395),(535,395),(640,395),
          (780,420),(960,405),(40,570),
          (170,570),(300,570),(430,570)]
    for ident,(xx,yy) in zip(ids,locs):
        a=f'smi.ui.fantasy01.wave2.{ident}'
        if a not in assets:continue
        img=draw_asset(a)
        if img.width>350 or img.height>250:img.thumbnail((350,240),Image.Resampling.LANCZOS)
        cover.paste(img,(xx,yy),img)
    d.text((50,861),f'{len(assets)} addressable assets   /   {kindcount["region"]} texture regions   /   {kindcount["state_set"]} state sets   /   {kindcount["composition"]} compositions',fill=(205,220,235),font=ImageFont.truetype(font_path,19))
    cover.save(OUT/'royal-forge-cover.png')

    summary={'schema':'smi-royal-forge-qa/1','artifact':ARCHIVE.name,
      'pack_sha256':hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
      'texture_count':len(textures),'asset_count':len(assets),'kinds':dict(kindcount),
      'regions_reviewed_in_contact_sheets':len(region_items),
      'states_sampled':len(state_changes),'sequence_transitions_tested':len(frame_changes),
      'source_original_asset_definitions_preserved':len(prev),
      'baseline_texture_corrections':['checkbox.square.disabled visual state made distinct'],
      'errors':errors,'warnings':warnings,
      'official_repo_zip_validator':'NOT RUN (repository source unavailable in local execution environment)',
      'official_creator_acceptance':'NOT RUN (repository test runner unavailable)',
      'official_chromium_builder_matrix':'NOT RUN (repository browser runtime unavailable)',
      'independent_dependency_geometry_state_checks':'PASS' if not errors else 'FAIL',
      'art_direction':'CANDIDATE, needs user approval',
      'distribution':'READY FOR PREVIEW' if not errors else 'NEEDS FIXES'}
    (OUT/'qa-report.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2)[:6000])
    assert not errors, 'Qualification failed: '+str(errors[:8])
