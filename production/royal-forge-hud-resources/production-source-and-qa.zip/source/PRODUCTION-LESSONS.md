# Royal Forge Resource Systems — Production lessons

## Findings from the actual production cycle

1. **The source sprite's data-bearing interval must be exact, not merely its logical size.**
   The first version rendered orb/vial fills as full 120×120/84×165 images with a transparent gutter. `clip(axis:y, origin:end)` clipped the padded texture rather than the actual liquid. Values 1%, 5%, 10%, 90%, 99%, and 100% falsely looked identical at the extremes. The right fix was to crop the **source liquid region** to the real interior (78×78 for globe; 38×117 for vial), set the composition offsets once (21,21 / 23,22), and rerun all numeric samples. Do **not** special-case the renderer or suppress pixel tests.

2. **Radial progression is not currently a continuous numeric binding.**
   `smi-visual-pack/1` supports x/y rectangular clipping, not angular clipping. This pack honestly authors 11 actual radial sprites and a `state_set` with `pct_000` through `pct_100`. Hosts select the appropriate state. Do not imply 0–100 continuous radial input works. If needed later, evolve the shared rendering contract explicitly after design review, rather than injecting custom per-pack JavaScript or a second renderer.

3. **A published state-family should be a discoverable group, not 17 individual 'featured' cards.**
   The generated catalog should derive parent-child membership from the existing `state_set.states` references and feature the **parent widget** before its state-member compositions/regions. Every child ID remains searchable and independently downloadable. Don't duplicate group membership as hand-edited registry metadata.

4. **Art-directed region packing needs measured pixel bounds.**
   The original vector shapes were rendered individually to RGBA, then packed using deterministic, explicit rectangles with 8px atlas gutters. Do not assume an image-generation layout has exact, evenly spaced cells. The contact sheets show every independent source region.

5. **Boundary-touch isn't categorically defective.**
   There are 11 intentional warnings from full-width/tight-extent fluid sprites (6 globe / 5 vial). They are within their declared regions with no overlapping neighbors, and the boundary contact is necessary for visible native low/high values. A better pixel scanner should report `intentional_full_bleed` as an explicitly audited result rather than silently claiming no issue. **Do not add that as a new manifest key** unless the schema evolves centrally.

6. **Test real pixels at every declared numeric interval.**
   The Python image QA and Chromium Canvas QA checked all 73 numeric controls at the 10 values mandated by `docs/ai/RELEASE-CHECKLIST.md` (0,1,5,10,25,50,75,90,99,100). A boolean "image changed" test alone is weak; include the raw per-step pixel-difference counts and verify minimum nonzero coverage. A future CI scenario should include exact endpoint fill geometry and negative assertions for hidden/occluded fills.

7. **Maintain source-of-truth discipline.**
   This pack uses existing region, sequence, state_set and composition kinds and ordinary typed inputs/behavior. The authored SVG and one generator are in `source/`; the generated manifest and textures are in the runtime ZIP. Source code and QA are distributed separately from runtime art. Never hand-edit the generated index and never write one renderer per pack.

## QA boundary / publication notes

- Independent creator-specific checks and Chromium Canvas tests passed on this pack.
- The repository's `tools/validate_visual_pack.py`, `tools/ai_acceptance.py`, `tools/qualify_asset_zip.py` and its actual Builder import/export plus official visual matrix were **NOT RUN** from this environment; exact repository checkout is unavailable in the local container. They must be run before public publication, and the result honestly recorded.
- The generated pack and source artwork are offered as **candidate** pending creator visual review and official integration gate.
- Automated state distinctness is not equivalent to artistic quality or gameplay usability. Human review remains required.

## Adaptive indicator / ornament layering corrections (v1.1)
- Static four-heart and six-pip snapshots were useful for catalog browsing but inadequate as live widgets. Keep those stable IDs and add canonical composition-layer `repeat` referencing the existing state family, controlled by `max`, `value`, and `columns`. The shared renderer measures natural width and row height; no per-heart custom canvas pipeline.
- A discrete `state_set` dropdown should also have a synchronized step slider. A numeric meter should have a draggable range with visible value and max capacity, and clamp value when max decreases. Never call discrete radial frames truly continuous.
- The combined royal/rune bar had duplicate full-width horizontal strokes drawn through frame studs and rune strokes. Fix the SVG base and rim paths, and place rune details within the frame before packing; inspect composite PNGs at real size.
- Pixel crop and manifest validation alone do not catch decorative stroke collisions. Require assembled screenshot visual QA and interactive state tests.
- For dynamically repeating indicators, test capacity 1 and 20, columns 5 and 10, and each quarter/full transition.
