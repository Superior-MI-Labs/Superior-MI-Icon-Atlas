#!/usr/bin/env python3
"""Royal Forge HUD Resource Systems: original SVG -> deterministic measured PNG atlas and Visual Atlas ZIP.
Only 4 existing asset kinds; no renderer changes, no second manifest registry.
"""
from __future__ import annotations
from pathlib import Path
from collections import Counter
import math, io, hashlib, json, zipfile, textwrap
import cairosvg
from PIL import Image, ImageDraw, ImageFont
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'source'; SVG_DIR=SRC/'svg'; SVG_DIR.mkdir(parents=True,exist_ok=True)
OUT=ROOT/'Royal-Forge-HUD-Resource-Systems-v1.1-Adaptive-Candidate.zip'
PREFIX='smi.hud.royalforge02'; STYLE='royal-forge-dark-gold'
# One palette shared by drawing logic, resource tags, badge glyphs and released artwork.
COLORS={
 'health':('#f4475d','#871b31','#ffc7b5'),
 'mana':('#40baff','#124cac','#ccf4ff'),
 'stamina':('#56d99b','#1a805e','#d6ffbc'),
 'shield':('#ffc65c','#a65b19','#fff3ac'),
 'experience':('#b781f7','#663bbb','#f7ceff'),
 'rage':('#ff793e','#ab2523','#ffd8a0'),
 'oxygen':('#5ae3e8','#1977aa','#c7fffe'),
 'focus':('#e08aff','#7b369a','#ffe0ff'),
 'heat':('#ffaf35','#c34224','#fff4a4'),
 'corruption':('#86db50','#376e38','#e4ffb0')
}
BAR_STYLES=['royal','runic','iron','verdant','arcane']
HEART_STYLES={'ruby':'health','crystal':'mana','amber':'shield','soul':'focus'}
PIP_STYLES={'ruby-gem':'health','mana-gem':'mana','shield-plate':'shield','stamina-leaf':'stamina','arcane-rune':'experience','rage-ember':'rage'}
ORB_STYLES=['health','mana','stamina','shield','experience','corruption']
RADIAL_STYLES=['health','mana','stamina','shield','experience','heat']
VIAL_STYLES=['health','mana','stamina','experience','corruption']
BOSS_STYLES=['royal','runic','iron']
assets=[];sources=[];used=set()
GOLD='#d3a466';PALE='#fff0c7';DEEP='#101426'

def rootsvg(w,h,body,color='health'):
    bright,deep,light=COLORS[color]
    defs=f'''<defs>
<linearGradient id="gold" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#fff0ba"/><stop offset=".15" stop-color="#e2b46c"/><stop offset=".48" stop-color="#714026"/><stop offset=".7" stop-color="#dfad60"/><stop offset="1" stop-color="#714423"/></linearGradient>
<linearGradient id="goldside" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#fff1c3"/><stop offset=".36" stop-color="#9d6b3c"/><stop offset=".8" stop-color="#f1c784"/><stop offset="1" stop-color="#825029"/></linearGradient>
<linearGradient id="metal" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#3a465c"/><stop offset=".44" stop-color="#171d30"/><stop offset="1" stop-color="#080d1c"/></linearGradient>
<linearGradient id="light" x1="0" y1="0" x2="0" y2="1"><stop stop-color="{light}"/><stop offset=".17" stop-color="{bright}"/><stop offset=".58" stop-color="{deep}"/><stop offset="1" stop-color="{bright}"/></linearGradient>
<radialGradient id="orb" cx="35%" cy="29%" r="80%"><stop stop-color="#ffffff" stop-opacity=".82"/><stop offset=".18" stop-color="{light}"/><stop offset=".51" stop-color="{bright}"/><stop offset=".83" stop-color="{deep}"/><stop offset="1" stop-color="#080d26"/></radialGradient>
<radialGradient id="shine"><stop stop-color="{light}" stop-opacity=".95"/><stop offset=".7" stop-color="{bright}" stop-opacity=".3"/><stop offset="1" stop-color="{bright}" stop-opacity="0"/></radialGradient>
<clipPath id="heartshape"><path d="M 36 61 C 26 52 7 39 7 24 C 7 3 29 4 36 17 C 45 4 66 3 66 24 C 66 39 46 53 36 61Z"/></clipPath>
<clipPath id="orbclip"><circle cx="60" cy="60" r="46"/></clipPath>
<clipPath id="vialclip"><rect x="23" y="21" width="38" height="119" rx="12"/></clipPath>
</defs>'''
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">{defs}{body}</svg>'

def jewel(x,y,r=8):
    return (f'<circle cx="{x}" cy="{y}" r="{r+3}" fill="#070a17" stroke="#b78c53" stroke-width="2"/>'
            f'<path d="M {x} {y-r}L {x+r*.86} {y}L{x} {y+r}L{x-r*.86} {y}Z" fill="url(#orb)" stroke="#ffe6ae" stroke-width="1.1"/>'
            f'<path d="M{x-r*.28} {y-2}L{x} {y-r*.62}L{x+r*.32} {y-2}" fill="none" stroke="#fff" stroke-opacity=".8" stroke-width="1"/>')

def rune(x,y,n=0):
    symbols=['M-6 -8V9M-6 -8L6 -2L-6 4M-6 4L7 10','M-6 -10L7 -3L-3 1L5 10','M-7 -9L1 -9L6 0L-3 0L-4 10','M-7 -8L6 10M6 -8L-7 10']
    return f'<g transform="translate({x} {y}) scale(.52)" fill="none" stroke="#fee1a3" stroke-opacity=".95" stroke-width="2.4"><path d="{symbols[n%4]}"/></g>'

def emblem(resource,w=55,h=55):
    cx=w/2;cy=h/2
    # A dedicated, always recognizable resource symbol on a dark gold-medallion background.
    b=(f'<circle cx="{cx}" cy="{cy}" r="25" fill="#0b1020" stroke="#5d3a23" stroke-width="3"/>'
       f'<circle cx="{cx}" cy="{cy}" r="22" fill="url(#gold)" stroke="#ffe3a0" stroke-width="1"/>'
       f'<circle cx="{cx}" cy="{cy}" r="18.5" fill="url(#metal)" stroke="#f4c57b" stroke-width="1.4"/>')
    if resource=='health':
        b+=f'<path d="M 27 41 C16 32 15 23 21 20 C25 17 29 20 28 24 C33 15 44 17 44 26 C44 33 35 40 27 41Z" fill="url(#orb)" stroke="#ffbbb0" stroke-width="1.3"/>'
    elif resource in ('mana','oxygen'):
        b+=f'<path d="M27 12C21 23 15 28 16 34C17 47 37 46 39 33C40 26 32 19 27 12Z" fill="url(#orb)" stroke="#bafcff" stroke-width="1.3"/>'
    elif resource=='stamina':
        b+=f'<path d="M36 12 L19 31 H28 L23 45 L40 25 H31 Z" fill="url(#orb)" stroke="#fff6c2" stroke-width="1.4"/>'
    elif resource=='shield':
        b+=f'<path d="M27 12 L40 18 V29 Q39 39 27 44 Q15 39 14 29 V18Z" fill="url(#orb)" stroke="#fff4ba" stroke-width="1.4"/><path d="M27 18V39 M18 27H35" stroke="#fff0b0" stroke-width="2"/>'
    elif resource=='experience':
        b+=f'<path d="M27 11 L32 23L45 24L35 32L38 44L27 37L16 44L19 32L9 24L22 23Z" fill="url(#orb)" stroke="#fbe7ff" stroke-width="1"/>'
    elif resource in ('heat','rage'):
        b+=f'<path d="M29 11Q15 24 20 31Q13 26 16 18Q6 34 20 43Q37 49 42 33Q44 24 33 14Q36 26 27 30Q23 24 29 11Z" fill="url(#orb)" stroke="#ffe1ad" stroke-width="1.3"/>'
    elif resource=='focus':
        b+=f'<circle cx="27" cy="27" r="13" fill="none" stroke="url(#orb)" stroke-width="4"/><circle cx="27" cy="27" r="6" fill="url(#orb)"/>'
    else:
        b+=f'<path d="M27 11Q37 15 39 26Q33 25 32 35Q26 40 17 38Q23 32 17 25Q14 18 27 11Z" fill="url(#orb)" stroke="#e7ffae" stroke-width="1.5"/>'
    for ang in [0,90,180,270]:
        a=math.radians(ang);x=cx+math.cos(a)*22;y=cy+math.sin(a)*22
        b+=f'<circle cx="{x:.1f}" cy="{y:.1f}" r="2" fill="#fff1b9"/>'
    return b

def bar_base(style):
    w,h=350,62
    bg=(f'<path d="M17 8H331L342 30L331 54H17L7 31Z" fill="#070c16" stroke="#4d372d" stroke-width="3"/>'
        f'<path d="M19 12H328L336 31L328 50H19L12 31Z" fill="url(#gold)" stroke="#ffebba" stroke-width="1.3"/>'
        f'<path d="M27 17H322L330 31L322 45H27L20 31Z" fill="url(#metal)" stroke="#503a32" stroke-width="2"/>'
        f'<rect x="23" y="21" width="304" height="20" rx="2" fill="#050a16" stroke="#171e2e"/>'
        '')
    if style=='royal':
        for x in [26,68,154,239,322]:bg+=jewel(x,12,4)
    elif style=='runic':
        for x in range(36,330,49):bg+=rune(x,12,x//50)
    elif style=='iron':
        for x in range(19,328,34):bg+=f'<circle cx="{x}" cy="14" r="2.3" fill="#c9d7e6" stroke="#344057" stroke-width="1"/>'
        bg+=f'<path d="M19 49H331" stroke="#a5b9d1" stroke-width="3" opacity=".35"/>'
    elif style=='verdant':
        bg+=f'<path d="M19 14Q60 2 93 13T170 14T251 11T330 13" fill="none" stroke="#6e9861" stroke-width="4"/>'
        for x in range(36,317,55):bg+=f'<path d="M{x} 13 Q{x-14} 3 {x-8} 22 Q{x+5} 26 {x} 13Z" fill="#63af76" stroke="#c0d69a" stroke-width="1"/>'
    elif style=='arcane':
        bg+=f'<path d="M18 12H330" stroke="#bd81ff" stroke-width="2" stroke-dasharray="2 7"/>'
        for x in [39,94,171,248,305]:bg+=f'<circle cx="{x}" cy="50" r="3.2" fill="#8b58d2" stroke="#edc4ff" stroke-width="1"/>'
    return bg

def bar_rim(style):
    b=(f'<path d="M18 9L8 30L18 53H331L341 30L331 9" fill="none" stroke="url(#gold)" stroke-width="4"/>'
       f'<path d="M25 18L18 30L25 44H323L331 30L323 18" fill="none" stroke="#ffe9b7" stroke-opacity=".4" stroke-width="1"/>'
       ''
       f'<path d="M26 43H323" stroke="#e9aa60" stroke-width="1.2" opacity=".62"/>')
    if style in ('royal','runic','arcane'):
        for x in [18,332]:b+=jewel(x,30,5)
    return b

def fill_bar(resource,w=306,h=22):
    b=(f'<rect x="1" y="1" width="303" height="20" rx="2" fill="url(#light)"/>'
       f'<path d="M2 3H303" stroke="#fff" stroke-opacity=".75" stroke-width="1.6"/>'
       f'<path d="M2 18H303" stroke="#000" stroke-opacity=".3" stroke-width="1"/>')
    for x in range(16,288,28):b+=f'<path d="M{x} 3L{x+11} 18" stroke="#fff" stroke-opacity=".17" stroke-width="2"/>'
    for x in [18,60,116,172,240,282]:b+=f'<circle cx="{x}" cy="11" r="2" fill="#fff" opacity=".35"/>'
    return b

def heart_art(style,quarters):
    resource=HEART_STYLES[style];t=quarters/4
    b=(f'<path d="M36 61 C26 52 7 39 7 24 C7 3 29 4 36 17 C45 4 66 3 66 24 C66 39 46 53 36 61Z" fill="#0a1122" stroke="#6b4b35" stroke-width="4"/>'
       f'<path d="M36 57 C26 48 11 37 11 24 C11 10 28 8 36 22 C44 8 62 10 62 24 C62 37 47 49 36 57Z" fill="#283044"/>'
       f'<g clip-path="url(#heartshape)"><rect x="6" y="{62-54*t:.1f}" width="61" height="{54*t:.1f}" fill="url(#orb)"/>'
       f'<path d="M18 22Q26 12 33 24" stroke="#fff" stroke-width="3.4" fill="none" opacity=".55"/></g>'
       f'<path d="M36 61 C26 52 7 39 7 24 C7 3 29 4 36 17 C45 4 66 3 66 24 C66 39 46 53 36 61Z" fill="none" stroke="url(#gold)" stroke-width="3"/>'
       f'<path d="M17 24Q24 11 32 21" stroke="#fff7e0" stroke-width="1.6" fill="none" opacity=".75"/>')
    if style=='crystal':b+=f'<path d="M36 17L27 36L36 57L45 36Z" fill="none" stroke="#e1f5ff" stroke-opacity=".42"/>'
    if style=='amber':b+=f'<path d="M36 11V53" stroke="#ffe1b0" stroke-width="1" opacity=".6"/>'
    if style=='soul':b+=f'<circle cx="36" cy="33" r="18" fill="none" stroke="#ddb8ff" opacity=".35"/>'
    return b

def pip_art(style,full):
    resource=PIP_STYLES[style];center=(32,32)
    if 'gem' in style or 'rune' in style:
        shape='M32 8L54 32L32 56L10 32Z'
    elif 'plate' in style:
        shape='M32 6L53 16V39Q45 52 32 58Q19 52 11 39V16Z'
    elif 'leaf' in style:
        shape='M14 48Q9 15 52 10Q55 48 14 48Z'
    else:shape='M32 7Q52 23 47 41Q38 57 30 55Q11 45 14 30Q14 18 32 7Z'
    b=f'<path d="{shape}" fill="{"url(#orb)" if full else "#14192b"}" stroke="url(#gold)" stroke-width="4" stroke-linejoin="round"/>'
    b+=f'<path d="M20 25L32 14L44 25" fill="none" stroke="#fff4cd" stroke-width="1.8" opacity="{.8 if full else .25}"/>'
    if full:b+=f'<circle cx="32" cy="33" r="5" fill="#fff7e0" opacity=".65"/>'
    else:b+='<path d="M25 32L32 25L39 32L32 39Z" fill="none" stroke="#685b57" stroke-width="2"/>'
    return b

def orb_base(resource):
    b=('<circle cx="60" cy="60" r="52" fill="#090e1d" stroke="#654328" stroke-width="2"/>'
       '<circle cx="60" cy="60" r="48" fill="url(#metal)" stroke="#a17745" stroke-width="3"/>'
       '<circle cx="60" cy="60" r="45" fill="#070e21" stroke="#d0a463" stroke-opacity=".65"/>')
    for a in [0,90,180,270]:
        th=math.radians(a);b+=jewel(round(60+math.cos(th)*49,2),round(60+math.sin(th)*49,2),5)
    return b

def orb_fill(resource):
    # Local 78px fluid interval: no hidden 10%-wide transparent gutter at endpoints.
    # This circle sits strictly inside the ornate outer frame. One percent is visible.
    return ('<defs><clipPath id="fluid-circle"><circle cx="39" cy="39" r="39"/></clipPath></defs>'
            '<g clip-path="url(#fluid-circle)"><circle cx="39" cy="39" r="39" fill="url(#orb)"/>'
            '<path d="M2 46Q20 33 39 46T76 40" fill="none" stroke="#fff" stroke-opacity=".38" stroke-width="2"/>'
            '<ellipse cx="27" cy="19" rx="12" ry="5" transform="rotate(-20 27 19)" fill="#fff" opacity=".28"/></g>')

def orb_rim(resource):
    b=('<circle cx="60" cy="60" r="49" fill="none" stroke="url(#gold)" stroke-width="7"/>'
       '<circle cx="60" cy="60" r="43" fill="none" stroke="#ffe9b9" stroke-width="1" opacity=".65"/>'
       '<path d="M25 30Q58 1 93 30" fill="none" stroke="#fff" stroke-opacity=".48" stroke-width="2"/>')
    for a in [0,90,180,270]:
        th=math.radians(a);b+=jewel(round(60+math.cos(th)*49,2),round(60+math.sin(th)*49,2),5)
    return b

def radial(resource,pct):
    r=47;cx=66;cy=66
    length=2*math.pi*r;t=pct/100
    b=(f'<circle cx="{cx}" cy="{cy}" r="56" fill="#080d1e" stroke="#654427" stroke-width="3"/>'
       f'<circle cx="{cx}" cy="{cy}" r="48" fill="none" stroke="#19243b" stroke-width="15"/>'
       f'<circle cx="{cx}" cy="{cy}" r="48" fill="none" stroke="url(#gold)" stroke-width="2"/>'
       f'<circle cx="{cx}" cy="{cy}" r="47" fill="none" stroke="url(#light)" stroke-width="12" '
       f'stroke-dasharray="{length*t:.2f} {length*(1-t):.2f}" transform="rotate(-90 {cx} {cy})" stroke-linecap="butt"/>'
       f'<circle cx="{cx}" cy="{cy}" r="35" fill="url(#metal)" stroke="#926037" stroke-width="2"/>')
    for i in range(12):
        th=2*math.pi*i/12-math.pi/2
        x1=cx+math.cos(th)*55;y1=cy+math.sin(th)*55
        x2=cx+math.cos(th)*59;y2=cy+math.sin(th)*59
        b+=f'<path d="M{x1:.2f} {y1:.2f}L{x2:.2f} {y2:.2f}" stroke="#ffdf9d" stroke-width="2"/>'
    b+=jewel(cx,cy,18)
    b+='<circle cx="66" cy="66" r="3" fill="#fff8e7"/>'
    return b

def vial_base(resource):
    return ('<rect x="16" y="12" width="52" height="142" rx="14" fill="#090f20" stroke="#533823" stroke-width="4"/>'
            '<rect x="19" y="18" width="46" height="129" rx="12" fill="url(#metal)" stroke="#b08a5d" stroke-width="2"/>'
            '<rect x="23" y="21" width="38" height="119" rx="12" fill="#060d1b" stroke="#443a36" stroke-width="1"/>')

def vial_fill(resource):
    # Fluid is a tightly cropped 38x117 px interior. The vial's outline lives elsewhere.
    return ('<rect x="0" y="0" width="38" height="117" fill="url(#light)"/>'
            '<path d="M5 2V109" stroke="#fff" stroke-opacity=".48" stroke-width="4"/>'
            '<circle cx="24" cy="99" r="3" fill="#fff" opacity=".36"/>'
            '<circle cx="15" cy="65" r="2" fill="#fff" opacity=".3"/>')

def vial_rim(resource):
    return ('<rect x="17" y="12" width="50" height="140" rx="15" fill="none" stroke="url(#gold)" stroke-width="5"/>'
            '<path d="M23 21V142" fill="none" stroke="#fff1be" stroke-width="1" opacity=".6"/>'
            '<rect x="17" y="3" width="50" height="17" rx="5" fill="url(#gold)" stroke="#ffefb8" stroke-width="1.2"/>'
            '<rect x="17" y="145" width="50" height="16" rx="5" fill="url(#gold)" stroke="#ffefb8" stroke-width="1.2"/>')

def boss_base(style):
    b=('<path d="M25 11H544L559 40L543 71H25L10 40Z" fill="#070b18" stroke="#2d2334" stroke-width="5"/>'
       '<path d="M27 14H543L553 40L541 67H27L17 40Z" fill="url(#gold)" stroke="#f5dfa4" stroke-width="1"/>'
       '<path d="M34 20H536L543 41L535 60H34L26 41Z" fill="url(#metal)"/>'
       '<rect x="33" y="32" width="504" height="20" fill="#050a15"/>')
    if style=='royal':
        for x in [31,105,285,467,539]:b+=jewel(x,18,5)
    elif style=='runic':
        for x in [65,145,225,305,385,465]:b+=rune(x,16,x//80)
    else:
        for x in range(55,540,40):b+=f'<circle cx="{x}" cy="20" r="2.5" fill="#b7cbdd"/>'
    return b

def boss_rim(style):
    return ('<path d="M24 9H545L559 40L543 72H24L9 40Z" fill="none" stroke="url(#gold)" stroke-width="4"/>'
            '<path d="M32 25H538" stroke="#fff0ba" stroke-width="1.6"/>'
            '<path d="M32 57H538" stroke="#bd8b55" stroke-width="1.6"/>'
            +jewel(14,40,7)+jewel(555,40,7))

def fx_body(kind,i):
    if kind=='sparkle':
        r=7+i*3
        return (f'<circle cx="40" cy="40" r="{r*2}" fill="url(#shine)" opacity="{.45-i*.07}"/>'
                f'<path d="M40 {40-r}L{43+i} 37L{40+r} 40L43 43L40 {40+r}L37 43L{40-r} 40L37 37Z" fill="url(#light)" stroke="#fff1ba" opacity="{1-i*.13}"/>')
    r=12+i*7
    return (f'<circle cx="40" cy="40" r="{r}" fill="none" stroke="url(#light)" stroke-width="{4-i*.55}" opacity="{.95-i*.18}"/>'
            f'<circle cx="40" cy="40" r="8" fill="url(#shine)" opacity="{.5-i*.09}"/>')

def new_asset(slug,kind,**attrs):
    ident=f'{PREFIX}.{slug}'
    if ident in used:raise ValueError('Duplicate '+ident)
    used.add(ident)
    asset={'id':ident,'kind':kind,**attrs};assets.append(asset)
    return ident

def region(name,w,h,body,color='health',tags=(),subject='ui.hud.resources',style=STYLE):
    svg=rootsvg(w,h,body,color)
    img=Image.open(io.BytesIO(cairosvg.svg2png(bytestring=svg.encode(),output_width=w,output_height=h))).convert('RGBA')
    bbox=img.getchannel('A').getbbox()
    if bbox is None:raise ValueError('blank region: '+name)
    (SVG_DIR/(name+'.svg')).write_text(svg,encoding='utf-8')
    asset=new_asset(name,'region',name=name.replace('.',' ').replace('-',' ').title(),style=style,
                tags=list(dict.fromkeys([*name.split('.'),*tags,'fantasy','rpg','hud','royal-forge'])),subjects=[subject],
                texture='',rect_px=[],description='Original illustrated game-ready Royal Forge resource element.')
    sources.append((assets[-1],img));return asset

def composition(name,title,size,layers,inputs=None,behavior=None,tags=(),subject='ui.hud.resources',style=STYLE):
    kwargs={'name':title,'size_px':list(size),'layers':layers,'style':style,
            'tags':list(dict.fromkeys([*name.split('.'),*tags,'fantasy','rpg','hud'])),
            'subjects':[subject]}
    if inputs:kwargs['inputs']=inputs
    if behavior:kwargs['behavior']=behavior
    return new_asset('widget.'+name,'composition',**kwargs)

def states(name,title,mapping,default,tags=(),subject='ui.hud.resources'):
    return new_asset(name+'.states','state_set',name=title+' States',states=mapping,default_state=default,
                     style=STYLE,tags=list(dict.fromkeys([*name.split('.'),*tags,'states','fantasy','rpg','hud'])),subjects=[subject])

def sequence(name,title,frame_ids,fps=8,subject='ui.hud.effects'):
    return new_asset(name+'.animation','sequence',name=title,frames=[{'asset':a} for a in frame_ids],default_fps=fps,
                     playback='loop',style=STYLE,tags=['animated','hud','fx','fantasy',name],subjects=[subject])

def inp(default=72,maxi=100):return {'value':{'type':'number','default':default,'min':0,'max':maxi}}
def value_behavior(role='meter'):
    return {'role':role,'outputs':{'value':{'from_input':'value','unit':'percent'}},
            'on':{'set_value':[{'op':'set','input':'value','source':'event.value'},{'op':'emit','event':'value_changed'}]}}

def build_assets():
    shells={}
    for st in BAR_STYLES:
        shells[st]=(region(f'bar.{st}.base',350,62,bar_base(st),tags=['track','frame','backplate'],subject='ui.hud.bars'),
                    region(f'bar.{st}.rim',350,62,bar_rim(st),tags=['metal','gold','border'],subject='ui.hud.bars'))
    fills={r:region(f'bar.fill.{r}',306,22,fill_bar(r),r,tags=['fill',r,'progress'],subject='ui.hud.bars') for r in COLORS}
    badges={r:region(f'emblem.{r}',55,55,emblem(r),r,tags=['symbol',r,'badge'],subject='ui.hud.badges') for r in COLORS}
    for st,(base,rim) in shells.items():
        for res in COLORS:
            composition(f'bar.{st}.{res}',f'{st.title()} {res.title()} Bar', (399,72),[
                {'id':'backplate','asset':base,'offset_px':[40,5]},
                {'id':'fill','asset':fills[res],'offset_px':[61,25], 'clip':{'input':'value','axis':'x','origin':'start'}},
                {'id':'gold-rim','asset':rim,'offset_px':[40,5]},
                {'id':'resource-emblem','asset':badges[res],'offset_px':[1,9]}],
                inp(),value_behavior(),tags=['health-bar','mana-bar','progress','resource',st,res],subject='ui.hud.bars')
    hearts={}
    for style,res in HEART_STYLES.items():
        parts={}
        for q in range(5):
            parts[q]=region(f'heart.{style}.q{q}',72,72,heart_art(style,q),res,
                            tags=['life','quarter-heart','fractional',style,'empty' if not q else 'full' if q==4 else 'partial'],subject='ui.hud.hearts')
        hearts[style]=parts
        states(f'heart.{style}',f'{style.title()} Fractional Heart',{'empty':parts[0], 'quarter':parts[1],'half':parts[2],'three_quarter':parts[3],'full':parts[4]},'full',
               tags=['health','quarter','hearts'],subject='ui.hud.hearts')
    # One runtime-bound layout rather than hundreds of pregenerated four-heart combinations.
    # The shared composition-layer repeat contract selects existing state_set regions.
    for style in HEART_STYLES:
        composition(f'hearts.{style}.adaptive',f'{style.title()} Adaptive Quarter Hearts', (738,150), [
            {'id':'icons','asset':f'{PREFIX}.heart.{style}.states',
             'repeat':{'count_input':'max','value_input':'value','columns_input':'columns',
                       'levels':['empty','quarter','half','three_quarter','full'],
                       'gap_px':[2,6]}}],
            {'max':{'type':'number','default':4,'min':1,'max':20,'step':1},
             'columns':{'type':'number','default':10,'min':1,'max':20,'step':1},
             'value':{'type':'number','default':12,'min':0,'max':80,'step':1}},
            {'role':'meter','outputs':{'value':{'from_input':'value','unit':'quarter hearts'},
                                       'max':{'from_input':'max','unit':'hearts'}},
             'on':{'set_value':[{'op':'set','input':'value','source':'event.value'},
                                {'op':'emit','event':'value_changed'}]}},
            tags=['adaptive','wrapped','multi-row','dynamic','quarter-heart','hearts','health'],subject='ui.hud.hearts')
    for style in ['ruby','crystal']:
        mapping={}
        for hp in range(17):
            layers=[{'id':f'heart_{i+1}','asset':hearts[style][max(0,min(4,hp-4*i))], 'offset_px':[i*74,0]} for i in range(4)]
            ident=composition(f'hearts.{style}.hp{hp:02d}',f'{style.title()} Hearts {hp}/16',(294,72),layers,
                              tags=['quarter-heart','fractional-health','health-counter',str(hp)],subject='ui.hud.hearts')
            mapping[f'hp_{hp:02d}']=ident
        states(f'hearts.{style}.counter',f'{style.title()} Four-Heart Counter',mapping,'hp_12',
               tags=['hp','health','sixteen-point','four-hearts'],subject='ui.hud.hearts')
    for style,res in PIP_STYLES.items():
        off=region(f'pip.{style}.empty',64,64,pip_art(style,False),res,tags=['segment','empty',style],subject='ui.hud.pips')
        on=region(f'pip.{style}.full',64,64,pip_art(style,True),res,tags=['segment','charged',style],subject='ui.hud.pips')
        piece=states(f'pip.{style}',f'{style.title()} Individual Pip',{'empty':off,'full':on},'full',
                    tags=['segment','one','charge'],subject='ui.hud.pips')
        composition(f'pips.{style}.adaptive',f'{style.title()} Adaptive Charge Pips',(724,134),[
            {'id':'icons','asset':piece,'repeat':{'count_input':'max','value_input':'value',
              'columns_input':'columns','levels':['empty','full'],'gap_px':[8,6]}}],
            {'max':{'type':'number','default':6,'min':1,'max':20,'step':1},
             'columns':{'type':'number','default':10,'min':1,'max':20,'step':1},
             'value':{'type':'number','default':4,'min':0,'max':20,'step':1}},
            {'role':'meter','outputs':{'value':{'from_input':'value','unit':'charged'},
                                      'max':{'from_input':'max','unit':'pips'}},
             'on':{'set_value':[{'op':'set','input':'value','source':'event.value'},
                              {'op':'emit','event':'value_changed'}]}},
            tags=['adaptive','wrapped','multi-row','dynamic','pips',style],subject='ui.hud.pips')
        mapping={}
        for n in range(7):
            ident=composition(f'pips.{style}.{n}of6',f'{style.title()} {n}/6',(384,64),[
                {'id':f'pip_{i}','asset':on if i<n else off,'offset_px':[i*64,0]} for i in range(6)],
                tags=['segmented-health','charges','pips',style],subject='ui.hud.pips')
            mapping[f'charge_{n}']=ident
        states(f'pips.{style}.meter',f'{style.title()} Six-Pip Meter',mapping,'charge_4',
               tags=['segmented','meter','charges','health'],subject='ui.hud.pips')
    for res in ORB_STYLES:
        base=region(f'orb.{res}.backplate',120,120,orb_base(res),res,tags=['orb','glass','backplate',res],subject='ui.hud.orbs')
        fill=region(f'orb.{res}.fluid',78,78,orb_fill(res),res,tags=['orb','liquid','fluid',res],subject='ui.hud.orbs')
        rim=region(f'orb.{res}.rim',120,120,orb_rim(res),res,tags=['orb','ring','border',res],subject='ui.hud.orbs')
        composition(f'orb.{res}',f'{res.title()} Globe',(120,120),[
            {'id':'vessel','asset':base,'offset_px':[0,0]},
            {'id':'resource','asset':fill,'offset_px':[21,21], 'clip':{'input':'value','axis':'y','origin':'end'}},
            {'id':'decorative-rim','asset':rim,'offset_px':[0,0]}],inp(),value_behavior(),
            tags=['liquid','resource','orb','globe',res],subject='ui.hud.orbs')
    for res in VIAL_STYLES:
        base=region(f'vial.{res}.backplate',84,165,vial_base(res),res,tags=['vial','flask','container'],subject='ui.hud.vials')
        fill=region(f'vial.{res}.fluid',38,117,vial_fill(res),res,tags=['vial','liquid','fill'],subject='ui.hud.vials')
        rim=region(f'vial.{res}.rim',84,165,vial_rim(res),res,tags=['vial','frame','gold'],subject='ui.hud.vials')
        composition(f'vial.{res}',f'{res.title()} Vertical Vial',(84,165),[
            {'id':'vessel','asset':base,'offset_px':[0,0]},
            {'id':'resource','asset':fill,'offset_px':[23,22],'clip':{'input':'value','axis':'y','origin':'end'}},
            {'id':'rim','asset':rim,'offset_px':[0,0]}],inp(),value_behavior(),
            tags=['vertical-meter','glass','flask',res],subject='ui.hud.vials')
    for res in RADIAL_STYLES:
        mapping={}
        for pct in range(0,101,10):
            ident=region(f'radial.{res}.pct{pct:03d}',132,132,radial(res,pct),res,
                         tags=['radial','circular','dial',str(pct)],subject='ui.hud.radials')
            mapping[f'pct_{pct:03d}']=ident
        states(f'radial.{res}.meter',f'{res.title()} Circular Meter',mapping,'pct_070',
               tags=['progress-ring','radial','cooldown',res],subject='ui.hud.radials')
    boss_shell={st:(region(f'boss.{st}.base',570,81,boss_base(st),tags=['boss','encounter','frame'],subject='ui.hud.boss-bars'),
                    region(f'boss.{st}.rim',570,81,boss_rim(st),tags=['boss','metal','rim'],subject='ui.hud.boss-bars')) for st in BOSS_STYLES}
    for st,(base,rim) in boss_shell.items():
        for res in ['health','shield','rage','corruption']:
            composition(f'boss.{st}.{res}',f'{st.title()} Boss {res.title()} Bar',(585,81),[
                {'id':'boss-backplate','asset':base,'offset_px':[8,0]},
                {'id':'boss-resource','asset':fills[res],'offset_px':[41,32], 'size_px':[504,20], 'clip':{'input':'value','axis':'x','origin':'start'}},
                {'id':'boss-rim','asset':rim,'offset_px':[8,0]}],inp(78),value_behavior(),
                tags=['boss-bar','raid','encounter','health','progress',res],subject='ui.hud.boss-bars')
    for kind,res in [('sparkle','mana'),('pulse','health')]:
        frames=[region(f'fx.{kind}.{i}',80,80,fx_body(kind,i),res,tags=['particle','glow','visual-effect'],subject='ui.hud.effects') for i in range(4)]
        sequence('fx.'+kind,f'Royal Forge {kind.title()} Loop',frames,9,subject='ui.hud.effects')

def pack_atlases():
    sheets=[];placements=[];index=-1;cursor_x=0;cursor_y=0;row_h=0
    WIDTH=2048;HEIGHT=2048;PAD=8
    for asset,img in sorted(sources,key=lambda entry:(-entry[1].height,-entry[1].width,entry[0]['id'])):
        w,h=img.size
        if w+PAD*2>WIDTH or h+PAD*2>HEIGHT:raise ValueError('oversize sprite')
        if index<0 or cursor_y+h+PAD*2>HEIGHT:
            index+=1;sheets.append(Image.new('RGBA',(WIDTH,HEIGHT)))
            cursor_x=cursor_y=row_h=0
        if cursor_x+w+PAD*2>WIDTH:
            cursor_x=0;cursor_y+=row_h;row_h=0
        if cursor_y+h+PAD*2>HEIGHT:
            index+=1;sheets.append(Image.new('RGBA',(WIDTH,HEIGHT)))
            cursor_x=cursor_y=row_h=0
        x=cursor_x+PAD;y=cursor_y+PAD
        sheets[index].paste(img,(x,y))
        asset['texture']=f'atlas{index}';asset['rect_px']=[x,y,w,h]
        placements.append({'id':asset['id'],'atlas':index,'rect':asset['rect_px']})
        cursor_x+=w+PAD*2;row_h=max(row_h,h+PAD*2)
    return sheets,placements

def write_zip():
    build_assets();sheets,placements=pack_atlases()
    files={};textures={}
    for i,im in enumerate(sheets):
        name=f'textures/royal-forge-resources-{i:02}.png'
        buffer=io.BytesIO();im.save(buffer,format='PNG',optimize=True)
        data=buffer.getvalue();files[name]=data
        textures[f'atlas{i}']={'path':name,'width_px':im.width,'height_px':im.height,'sha256':hashlib.sha256(data).hexdigest(),'alpha':'straight','color_space':'srgb'}
        overview=im.copy();overview.thumbnail((1024,1024));overview.save(ROOT/'previews'/f'atlas-{i:02}-overview.png')
    manifest={'schema':'smi-visual-pack/1','pack_id':'smi.hud.royalforge02.resources','version':'1.1.0',
              'description':'Royal Forge fantasy RPG resource systems: bars, partial hearts, pips, orbs, vials, boss bars, and discrete radial gauges. Original vector artwork.',
              'license':'CC0-1.0','textures':textures,'assets':assets}
    collection={'schema':'smi-visual-collection/1','collection_id':'smi.royalforge02.resources',
                'name':'Royal Forge — HUD Resource Systems Vol. 1','version':'1.1.0','description':'Original fantasy RPG resource meters and life indicators',
                'packs':[{'manifest':'manifest.json'}],
                'entry_asset':f'{PREFIX}.widget.bar.royal.health'}
    files['manifest.json']=(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n').encode()
    files['collection.json']=(json.dumps(collection,indent=2)+'\n').encode()
    files['LICENSE.md']=b'Original vector artwork generated by Superior MI Labs Visual Atlas production; dedicated CC0-1.0 for this pack. No third-party game character/logo assets used.\n'
    files['README.md']=textwrap.dedent('''\
        # Royal Forge — HUD Resource Systems (Candidate)
        Original illustrated fantasy RPG UI with transparent sprite textures and portable manifests.

        ## Use
        Import this ZIP into the Superior MI Visual Atlas Builder. Open Royal Health Bar by default.
        All numeric horizontal bars, vertical vials and globe contents use 0–100 inputs and the existing
        Canvas 2D `clip` contract. See `value` in each widget input and `set_value` behavior event.

        ## Important host semantics
        Adaptive quarter hearts accept value in quarter units, max hearts (1..20), and columns (1..20);
        the renderer wraps rows and measures the output dynamically. Fixed four-heart historic states remain.
        Adaptive pip systems accept charge value, max pip count, and columns (1..20).
        Quarter-heart counters encode values 0..16 as explicit compositions and `hp_00`..`hp_16` states.
        Segmented pips encode `charge_0`..`charge_6`. Circular meters encode `pct_000`..`pct_100` in
        increments of 10. Host applications must select the appropriate state; these are intentionally
        not misrepresented as continuously bound numeric radial gauges.

        Preview effects are independent 4-frame sequences. Animation does not auto-bind to arbitrary events.
        Game input / runtime hit-testing remains the application's responsibility.
        ''').encode()
    ROOT.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=8) as z:
        for name,data in sorted(files.items()):
            info=zipfile.ZipInfo(name,date_time=(2020,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=0o644<<16;z.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=8)
    (SRC/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    (SRC/'collection.json').write_text(json.dumps(collection,indent=2)+'\n')
    (ROOT/'qa'/'layout.json').write_text(json.dumps({'textures':len(sheets),'placements':placements},indent=2)+'\n')
    (ROOT/'qa'/'inventory.json').write_text(json.dumps({'asset_total':len(assets),'kinds':Counter(a['kind'] for a in assets),'region_count':len(sources),'textures':len(sheets)},indent=2)+'\n')
    print('Wrote',OUT,'bytes',OUT.stat().st_size,'textures',len(sheets),'assets',len(assets),'by kind',dict(Counter(a['kind'] for a in assets)))
    return OUT
if __name__=='__main__':write_zip()
