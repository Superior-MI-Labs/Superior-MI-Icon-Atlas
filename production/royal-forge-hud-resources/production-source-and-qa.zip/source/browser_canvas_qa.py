#!/usr/bin/env python3
"""Chromium rendering of candidate manifest and original PNG, using source-equivalent Canvas 2D calls.
Not an official Visual Atlas Builder import or export/reimport test.
"""
from __future__ import annotations
import io, json, zipfile, base64
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
ARCHIVE=ROOT/'Royal-Forge-HUD-Resource-Systems-v1.1-Adaptive-Candidate.zip'
with zipfile.ZipFile(ARCHIVE) as z:
    manifest=json.loads(z.read('manifest.json'))
    src=next(iter(manifest['textures'].values()))['path']
    img64=base64.b64encode(z.read(src)).decode('ascii')
assets={a['id']:a for a in manifest['assets']}
js=r'''async ({assets,imageSource})=>{
 const map=new Map(Object.entries(assets));
 const img=new Image();img.src='data:image/png;base64,'+imageSource;
 await img.decode();
 const canvas=document.querySelector('canvas');
 const ctx=canvas.getContext('2d',{willReadFrequently:true});
 function dims(id){const a=map.get(id);if(!a)throw Error('Missing asset '+id);
  if(a.kind==='region')return a.logical_size_px||a.rect_px.slice(2,4);
  if(a.kind==='composition')return a.size_px;
  if(a.kind==='state_set')return dims(a.states[a.default_state]);
  return dims(a.frames[0].asset);
 }
 function draw(id,ctx,x,y,w,h,value,state=null,stack=new Set()){
  if(stack.has(id))throw Error('Reference cycle '+id);
  const a=map.get(id);if(!a)throw Error('Missing asset '+id);
  const next=new Set(stack);next.add(id);
  if(a.kind==='region'){ctx.drawImage(img,...a.rect_px,x,y,w,h);return;}
  if(a.kind==='state_set'){const k=(state&&a.states[state])?state:a.default_state;draw(a.states[k],ctx,x,y,w,h,value,null,next);return;}
  if(a.kind==='sequence'){draw(a.frames[0].asset,ctx,x,y,w,h,value,null,next);return;}
  if(a.kind!=='composition')throw Error('Unsupported asset '+a.kind);
  const inp=a.inputs?.value||{min:0,max:100,default:50};
  const v=value??inp.default;
  const t=Math.max(0,Math.min(1,(v-inp.min)/(inp.max-inp.min)));
  ctx.save();ctx.translate(x,y);ctx.scale(w/a.size_px[0],h/a.size_px[1]);
  for(const l of a.layers){
    const target=l.asset;const [lw,lh]=l.size_px||dims(target);
    const px=l.offset_px?.[0]||0,py=l.offset_px?.[1]||0;
    ctx.save();
    if(l.clip){let cw=l.clip.axis==='x'?lw*t:lw,ch=l.clip.axis==='y'?lh*t:lh;
      let cx=px,cy=py;if(l.clip.origin==='end'){
        if(l.clip.axis==='x')cx+=lw-cw;else cy+=lh-ch;
      }
      ctx.beginPath();ctx.rect(cx,cy,cw,ch);ctx.clip();
    }
    draw(target,ctx,px,py,lw,lh,v,null,next);
    ctx.restore();
  }
  ctx.restore();
 }
 const values=[0,1,5,10,25,50,75,90,99,100];let checked=0;
 const issues=[];const fingerprints={};
 function pixels(id,v,state){const [w,h]=dims(id);canvas.width=w;canvas.height=h;ctx.clearRect(0,0,w,h);
   draw(id,ctx,0,0,w,h,v,state);return ctx.getImageData(0,0,w,h).data;}
 function changes(a,b){let count=0;for(let i=0;i<a.length;i+=4){
   if(Math.max(Math.abs(a[i]-b[i]),Math.abs(a[i+1]-b[i+1]),Math.abs(a[i+2]-b[i+2]),Math.abs(a[i+3]-b[i+3]))>12)count++;
 }return count;}
 for(const a of assetsToCheck=Object.values(assets).filter(a=>a.kind==='composition'&&a.inputs?.value)){
   const samples=values.map(v=>pixels(a.id,v));
   const counts=samples.slice(1).map((curr,i)=>changes(curr,samples[i]));
   if(counts.some(x=>x<1))issues.push(a.id+': missing visible transition: '+counts.join(','));
   fingerprints[a.id]=counts;
   checked++;
 }
 for(const a of Object.values(assets).filter(a=>a.kind==='sequence')){
  if(a.frames.length<2||changes(pixels(a.frames[0].asset),pixels(a.frames[1].asset))===0)issues.push(a.id+': undifferentiated sequence frames');
 }
 for(const a of Object.values(assets).filter(a=>a.kind==='state_set')){
  let prev=null;
  for(const key of Object.keys(a.states)){
   const current=pixels(a.id,null,key);if(prev&&changes(prev,current)===0)issues.push(a.id+': visually identical adjacent states '+key);
   prev=current;
  }
 }
 // Negative test: corrupted asset resolution should throw rather than silently render.
 let rejected=false;try{draw('invalid.missing.asset',ctx,0,0,10,10,0);}catch{rejected=true}
 if(!rejected)issues.push('unknown asset was not rejected');
 const hero=Object.values(assets).find(a=>a.id.endsWith('widget.bar.royal.health'));
 pixels(hero.id,75);const heroPNG=canvas.toDataURL('image/png');
 return {checked,statesChecked:Object.values(assets).filter(a=>a.kind==='state_set').length,
         sequencesChecked:Object.values(assets).filter(a=>a.kind==='sequence').length,
         sampleValues:values,issues,heroPNG,exampleTransitions:fingerprints[hero.id]};
}'''
# Remove accidental assignment to const loop-head in JS: keep a straightforward for-of.
js=js.replace('for(const a of assetsToCheck=Object.values(assets).filter','for(const a of Object.values(assets).filter')
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    try:
        page=browser.new_page(viewport={'width':1000,'height':750});page.set_content('<!doctype html><title>Royal Forge manifest canvas QA</title><canvas width="600" height="200"></canvas>')
        result=page.evaluate(js,{'assets':assets,'imageSource':img64})
    finally:browser.close()
img=base64.b64decode(result.pop('heroPNG').split(',',1)[1]);(ROOT/'qa'/'chromium-canvas-health-75.png').write_bytes(img)
result['renderer']='Chromium Canvas 2D, manifest-derived test harness; NOT official Builder runtime'
(ROOT/'qa'/'chromium-canvas-report.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2)[:5000]);
if result['issues']:raise SystemExit('Chromium canvas QA failed')
