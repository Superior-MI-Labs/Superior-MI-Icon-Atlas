#!/usr/bin/env python3
"""Execute the creator-specific acceptance JSON against the generated runtime ZIP.
The spec uses the repository's documented smi-ai-acceptance/1 check types;
this independent evaluator is not the official tools/ai_acceptance.py runner.
"""
import hashlib, io, json, zipfile, sys
from pathlib import Path
from PIL import Image
R=Path(__file__).resolve().parents[1]
with zipfile.ZipFile(R/'Royal-Forge-HUD-Resource-Systems-v1.1-Adaptive-Candidate.zip') as archive:
    manifest=json.loads(archive.read('manifest.json'))
    records={a['id']:a for a in manifest['assets']}
    textures={key:Image.open(io.BytesIO(archive.read(info['path']))).convert('RGBA') for key,info in manifest['textures'].items()}
    spec=json.loads((R/'qa'/'creator-acceptance.json').read_text())
    errors=[];log=[]
    for index,rule in enumerate(spec['checks'],1):
        item=records.get(rule['asset']); kind=rule['type'];expected=rule
        if item is None:
            errors.append('Unknown asset '+rule['asset']);continue
        success=False
        if kind=='asset_kind':success=item['kind']==expected['kind']
        elif kind=='input_range':
            d=item.get('inputs',{}).get(expected['input'],{})
            success=(item['kind']=='composition' and d.get('type')=='number' and d.get('min')==expected['min'] and d.get('max')==expected['max'])
        elif kind=='layer_uses_input':
            ls=[layer for layer in item.get('layers',[]) if layer['id']==expected['layer']]
            success=len(ls)==1 and ls[0].get(expected['binding'],{}).get('input')==expected['input']
        elif kind=='layer_order':
            order=[layer['id'] for layer in item.get('layers',[])]
            success=expected['before'] in order and expected['after'] in order and order.index(expected['before'])<order.index(expected['after'])
        elif kind=='state_contains':success=item['kind']=='state_set' and expected['state'] in item.get('states',{})
        elif kind=='output_maps_from_input':
            success=item.get('behavior',{}).get('outputs',{}).get(expected['output'],{}).get('from_input')==expected['input']
        elif kind=='event_declared':success=expected['event'] in item.get('behavior',{}).get('on',{})
        elif kind=='sequence_frames':success=item['kind']=='sequence' and len(item.get('frames',[]))>=expected['at_least']
        elif kind=='sequence_distinct_frames':
            hashes=[]
            for f in item.get('frames',[]):
                a=records.get(f['asset'])
                if not a or a['kind']!='region':break
                x,y,w,h=a['rect_px'];data=textures[a['texture']].crop((x,y,x+w,y+h))
                hashes.append(hashlib.sha256(data.tobytes()).hexdigest())
            success=len(set(hashes))>=expected['at_least']
        else:errors.append('Unsupported acceptance type '+kind)
        log.append({'number':index,'type':kind,'asset':rule['asset'],'status':'PASS' if success else 'FAIL'})
        if not success:errors.append('Check '+str(index)+' FAIL: '+json.dumps(rule))
    receipt={'schema':'smi-royalforge-acceptance-result/1','checks':len(log),'passed':sum(x['status']=='PASS' for x in log),
             'failed':len(errors),'errors':errors,'results':log,
             'runner':'Independent creator-check evaluator; not the official repository tools/ai_acceptance.py'}
    (R/'qa'/'creator-acceptance-result.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print('Creator acceptance checks: '+str(receipt['passed'])+'/'+str(receipt['checks'])+' PASS')
    if errors:print('\n'.join(errors));sys.exit(1)
