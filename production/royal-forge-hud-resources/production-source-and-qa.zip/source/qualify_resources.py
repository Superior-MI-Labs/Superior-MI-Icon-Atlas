#!/usr/bin/env python3
"""Creator-specific independent pixel/state QA of the final self-contained ZIP.
Does not replace the repository's official browser/ZIP validators.
"""
from __future__ import annotations
import zipfile, json, io, hashlib, math, collections, sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageChops, ImageStat
ROOT=Path(__file__).resolve().parents[1]; ZIP=ROOT/'Royal-Forge-HUD-Resource-Systems-v1.1-Adaptive-Candidate.zip';QA=ROOT/'qa';PREVIEW=ROOT/'previews'
QA.mkdir(exist_ok=True);PREVIEW.mkdir(exist_ok=True)
with zipfile.ZipFile(ZIP) as z:
    names=set(z.namelist());manifest=json.loads(z.read('manifest.json'));collection=json.loads(z.read('collection.json'))
    textures={key:Image.open(io.BytesIO(z.read(value['path']))).convert('RGBA') for key,value in manifest['textures'].items()}
assets={asset['id']:asset for asset in manifest['assets']}
errors=[];warnings=[];test_log=[]
def check(cond,msg):
    if not cond:errors.append(msg)
def entry(asset):
    if isinstance(asset,str):return assets[asset]
    return asset

def sprite(asset):
    a=entry(asset);x,y,w,h=a['rect_px'];return textures[a['texture']].crop((x,y,x+w,y+h))

def draw(asset_id,value=None,state=None,frame_index=0,max_count=None,columns=None):
    a=assets[asset_id]
    if a['kind']=='region':return sprite(a)
    if a['kind']=='state_set':return draw(a['states'][state or a['default_state']],value=value)
    if a['kind']=='sequence':return draw(a['frames'][frame_index%len(a['frames'])]['asset'])
    repeating=next((l for l in a['layers'] if l.get('repeat')),None)
    defaults={k:v['default'] for k,v in a.get('inputs',{}).items()}
    if repeating:
        r=repeating['repeat'];count=int(max_count or defaults[r['count_input']]);cols=min(count,int(columns or defaults[r['columns_input']]))
        tw,th=draw(repeating['asset'],state=r['levels'][0]).size
        gx,gy=r.get('gap_px',[0,0]);w=cols*tw+(cols-1)*gx;h=((count+cols-1)//cols)*th+(((count+cols-1)//cols)-1)*gy
    else:w,h=a['size_px']
    canvas=Image.new('RGBA',(w,h))
    v=a.get('inputs',{}).get('value',{}).get('default',0) if value is None else value
    minv=a.get('inputs',{}).get('value',{}).get('min',0);maxv=a.get('inputs',{}).get('value',{}).get('max',100)
    t=max(0,min(1,(v-minv)/(maxv-minv))) if maxv>minv else 0
    for layer in a['layers']:
        if layer.get('repeat'):
            r=layer['repeat'];units=len(r['levels'])-1
            active=max(0,min(count*units,round(v)))
            off=layer.get('offset_px',[0,0]);tw,th=draw(layer['asset'],state=r['levels'][0]).size
            for i in range(count):
                level=max(0,min(units,active-i*units))
                tile=draw(layer['asset'],state=r['levels'][level])
                canvas.alpha_composite(tile,(off[0]+(i%cols)*(tw+gx),off[1]+(i//cols)*(th+gy)))
            continue
        art=draw(layer['asset'],value=value)
        if layer.get('size_px'):art=art.resize(tuple(layer['size_px']),Image.Resampling.BICUBIC)
        if layer.get('clip'):
            clip=layer['clip'];cut=Image.new('RGBA',art.size)
            if clip['axis']=='x':
                extent=max(0,min(art.width,round(art.width*t)))
                box=(0,0,extent,art.height) if clip['origin']=='start' else (art.width-extent,0,art.width,art.height)
            else:
                extent=max(0,min(art.height,round(art.height*t)))
                box=(0,0,art.width,extent) if clip['origin']=='start' else (0,art.height-extent,art.width,art.height)
            if extent:cut.paste(art.crop(box),(box[0],box[1]))
            art=cut
        off=layer.get('offset_px',[0,0]);canvas.alpha_composite(art,(int(off[0]),int(off[1])))
    return canvas

def diff_pixels(a,b):
    if a.size!=b.size:return -1
    d=ImageChops.difference(a,b)
    return sum(1 for px in d.get_flattened_data() if max(px)>12)

check(manifest.get('schema')=='smi-visual-pack/1','pack schema')
check(collection.get('schema')=='smi-visual-collection/1','collection schema')
check(len(assets)==len(manifest['assets']),'duplicate IDs')
check(collection['entry_asset'] in assets,'missing entry_asset')
check(manifest.get('license')=='CC0-1.0','pack license')
regions=[a for a in assets.values() if a['kind']=='region']
comps=[a for a in assets.values() if a['kind']=='composition']
states=[a for a in assets.values() if a['kind']=='state_set']
seqs=[a for a in assets.values() if a['kind']=='sequence']
occupied=collections.defaultdict(list)
for a in regions:
    x,y,w,h=a['rect_px'];t=textures.get(a['texture'])
    check(t is not None,'unknown texture '+a['id'])
    if t is None:continue
    check(x>=0 and y>=0 and w>0 and h>0 and x+w<=t.width and y+h<=t.height,'invalid bounds '+a['id'])
    im=sprite(a);bbox=im.getchannel('A').getbbox()
    check(bbox is not None,'empty region '+a['id'])
    if bbox and (bbox[0]==0 or bbox[1]==0 or bbox[2]==w or bbox[3]==h):warnings.append('border-touch '+a['id'])
    occupied[a['texture']].append((x,y,x+w,y+h,a['id']))
for key,rects in occupied.items():
    for i,a in enumerate(rects):
        for b in rects[i+1:]:
            if a[0]<b[2] and b[0]<a[2] and a[1]<b[3] and b[1]<a[3]:errors.append('overlap '+a[4]+' '+b[4])
for a in comps:
    for layer in a['layers']:
        check(layer.get('asset') in assets,'missing layer '+a['id']+' '+str(layer))
        if layer.get('clip'):
            check(layer['clip']['input'] in a.get('inputs',{}),'undefined clip input '+a['id'])
            check(layer['clip']['axis'] in ('x','y'),'bad clip axis '+a['id'])
            check(layer['clip']['origin'] in ('start','end'),'bad clip origin '+a['id'])
    if a.get('behavior'):
        for output,source in a['behavior'].get('outputs',{}).items():
            check(source['from_input'] in a.get('inputs',{}),'output input missing '+a['id'])
for a in states:
    check(a['default_state'] in a['states'],'missing default state '+a['id'])
    for name,ref in a['states'].items():check(ref in assets,'bad state reference '+a['id']+'/'+name)
for a in seqs:
    check(len(a['frames'])>=2,'short sequence '+a['id'])
    for fr in a['frames']:check(fr['asset'] in assets,'missing frame '+a['id'])
    hashes=[hashlib.sha256(draw(fr['asset']).tobytes()).digest() for fr in a['frames']]
    check(len(set(hashes))>=2,'non-animated animation '+a['id'])

# Manifest creator acceptance: validate actual references, cardinality, 10-point value response.
prefix='smi.hud.royalforge02.'
expected={'region':175,'composition':159,'state_set':24,'sequence':2}
check(collections.Counter(a['kind'] for a in assets.values())==expected,'asset family count regression')
for theme in ['royal','runic','iron','verdant','arcane']:
    for resource in ['health','mana','stamina','shield','experience','rage','oxygen','focus','heat','corruption']:
        name=prefix+f'widget.bar.{theme}.{resource}'
        check(name in assets,'missing bar '+name)
for style in ['ruby','crystal']:
    state=assets[prefix+f'hearts.{style}.counter.states']
    check(len(state['states'])==17,'fractional counter must have 17 states '+style)
    values=[draw(ref).tobytes() for ref in state['states'].values()]
    check(len(set(hashlib.sha256(p).digest() for p in values))==17,'heart states not distinct '+style)
for style in ['ruby-gem','mana-gem','shield-plate','stamina-leaf','arcane-rune','rage-ember']:
    state=assets[prefix+f'pips.{style}.meter.states']
    check(len(state['states'])==7,'pip states missing '+style)
    values=[hashlib.sha256(draw(ref).tobytes()).digest() for ref in state['states'].values()]
    check(len(set(values))==7,'pip states identical '+style)
for resource in ['health','mana','stamina','shield','experience','heat']:
    state=assets[prefix+f'radial.{resource}.meter.states']
    check(len(state['states'])==11,'radial steps missing '+resource)
    values=[hashlib.sha256(draw(ref).tobytes()).digest() for ref in state['states'].values()]
    check(len(set(values))==11,'radial states identical '+resource)

SAMPLES=[0,1,5,10,25,50,75,90,99,100]
numeric=comps and [a for a in comps if 'value' in a.get('inputs',{})]
for a in numeric:
    repeat=next((l for l in a['layers'] if l.get('repeat')),None)
    if repeat:
        capacity=a['inputs'][repeat['repeat']['count_input']]['default']*(len(repeat['repeat']['levels'])-1)
        # Every discrete quarter/charge increment must produce different pixels.
        sample_values=list(range(capacity+1))
    else:sample_values=SAMPLES
    seq=[draw(a['id'],value=v) for v in sample_values]
    comparisons=[diff_pixels(seq[i],seq[i+1]) for i in range(len(seq)-1)]
    # Comparing 0 and 1 catches hidden low-end fills. Full containment across themed frames might give small but nonzero diffs.
    if not all(n>0 for n in comparisons):errors.append('invisible value step '+a['id']+': '+str(comparisons))
    test_log.append({'id':a['id'],'pixel_changes_between_samples':comparisons})

# Dynamic measurements and explicitly distinct occupancy/row wrapping.
for style in ['ruby','crystal','amber','soul']:
    aid=prefix+f'widget.hearts.{style}.adaptive'
    check(draw(aid,value=3,max_count=1,columns=10).size==(72,72),'1-heart layout size '+style)
    check(draw(aid,value=63,max_count=20,columns=10).size==(738,150),'20-heart 10-column layout '+style)
    check(draw(aid,value=63,max_count=20,columns=5).size==(368,306),'20-heart 5-column layout '+style)
    check(diff_pixels(draw(aid,value=62,max_count=20,columns=10),draw(aid,value=63,max_count=20,columns=10))>0,'quarter changes '+style)
for style in ['ruby-gem','mana-gem','shield-plate','stamina-leaf','arcane-rune','rage-ember']:
    aid=prefix+f'widget.pips.{style}.adaptive'
    check(draw(aid,value=6,max_count=20,columns=10).size==(712,134),'20-pip 10-column layout '+style)
    check(diff_pixels(draw(aid,value=5,max_count=20,columns=10),draw(aid,value=6,max_count=20,columns=10))>0,'charge changes '+style)

# Contact sheets of all 175 regions: exact source crops, no generated image-grid assumptions.
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',13)
for start in range(0,len(regions),48):
    subset=regions[start:start+48];width=8*220;height=6*187
    sheet=Image.new('RGB',(width,height),'#101a2a');p=ImageDraw.Draw(sheet)
    for j,a in enumerate(subset):
        col=j%8;row=j//8;xx=col*220;yy=row*187
        p.rounded_rectangle((xx+3,yy+3,xx+215,yy+182),radius=8,fill='#19263d',outline='#425a77',width=1)
        art=sprite(a);art.thumbnail((196,142),Image.Resampling.LANCZOS)
        sheet.paste(art,(xx+(220-art.width)//2,yy+6+(143-art.height)//2),art)
        label=a['id'].split(prefix)[-1]
        p.text((xx+8,yy+153),label[:27],font=font,fill='#e6d9c1')
    name=QA/f'contact-regions-{start//48+1:02}.png';sheet.save(name)

# Image contact sheets of assembled resource samples: compare 0,5,25,50,75,100.
show=[prefix+'widget.bar.royal.health',prefix+'widget.bar.runic.mana',prefix+'widget.bar.verdant.stamina',prefix+'widget.bar.arcane.experience',prefix+'widget.bar.iron.shield',prefix+'widget.boss.royal.health',prefix+'widget.orb.health',prefix+'widget.orb.mana',prefix+'widget.vial.health',prefix+'widget.vial.experience']
contact=Image.new('RGB',(1600,len(show)*200),'#0a111d');p=ImageDraw.Draw(contact)
for ri,aid in enumerate(show):
    a=assets[aid];p.text((12,ri*200+8),a['name'],font=font,fill='#dfc58c')
    for j,v in enumerate([0,5,25,50,75,100]):
        im=draw(aid,value=v);im.thumbnail((242,145),Image.Resampling.LANCZOS)
        x=j*260+(260-im.width)//2;y=ri*200+42+(145-im.height)//2
        contact.paste(im,(x,y),im)
        p.text((j*260+111,ri*200+182),str(v)+'%',font=font,fill='#f3e4c7')
contact.save(QA/'value-state-matrix.jpg',quality=93)

# Promotional preview assembled from actual PNG regions and manifest compositions, not generated mock art.
W,H=1600,1300;cover=Image.new('RGB',(W,H),'#080e1a');d=ImageDraw.Draw(cover)
for x in range(0,W,50):d.line((x,0,x,H),fill='#101a2a',width=1)
for y in range(0,H,50):d.line((0,y,W,y),fill='#101a2a',width=1)
fontT=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',42)
fontH=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',22)
fontS=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',15)
d.text((58,35),'ROYAL FORGE',font=fontT,fill='#e8c27d')
d.text((62,92),'HUD RESOURCE SYSTEMS • ORIGINAL GAME UI ASSET PACK',font=fontH,fill='#d7e0ec')
d.line((60,125,1540,125),fill='#ae7b3d',width=2)
blocks=[('MULTI-STYLE RESOURCE BARS',(65,162)),('BOSS / ENCOUNTER METERS',(65,510)),('FRACTIONAL HEARTS & CHARGES',(65,710)),('ORBS, VIALS & CIRCULAR METERS',(65,925))]
for label,(x,y) in blocks:d.text((x,y),label,font=fontH,fill='#e3c68c')
barlist=[('royal','health'),('runic','mana'),('verdant','stamina'),('iron','shield'),('arcane','experience')]
for i,(style,res) in enumerate(barlist):
    im=draw(prefix+f'widget.bar.{style}.{res}',value=[84,59,73,45,92][i]);im.thumbnail((430,68));
    x=70+(i%3)*505;y=210+(i//3)*125
    cover.paste(im,(x,y),im);d.text((x+26,y+70),style.title()+' '+res.title(),font=fontS,fill='#c6d6e7')
for i,res in enumerate(['health','shield','rage','corruption']):
    im=draw(prefix+f'widget.boss.royal.{res}',value=[77,56,89,33][i]);im.thumbnail((690,90));x=65+(i%2)*795;y=558+(i//2)*74
    cover.paste(im,(x,y),im)
for i,style in enumerate(['ruby','crystal']):
    im=draw(prefix+f'hearts.{style}.counter.states',state='hp_11');x=65+i*380;cover.paste(im,(x,766),im)
for i,style in enumerate(['ruby-gem','mana-gem']):
    im=draw(prefix+f'pips.{style}.meter.states',state='charge_4');x=835+i*365;im.thumbnail((315,58));cover.paste(im,(x,780),im)
for i,res in enumerate(['health','mana','stamina','shield','experience','corruption']):
    im=draw(prefix+f'widget.orb.{res}',value=82);x=65+i*125;cover.paste(im,(x,990),im)
for i,res in enumerate(['health','mana','stamina','experience','corruption']):
    im=draw(prefix+f'widget.vial.{res}',value=64);x=850+i*108;cover.paste(im,(x,975),im)
for i,res in enumerate(['health','mana','shield','experience','heat']):
    im=draw(prefix+f'radial.{res}.meter.states',state='pct_070');x=70+i*156;cover.paste(im,(x,1123),im)
d.text((960,1230),'360 ASSETS   •   CC0   •   1 ATLAS',font=fontH,fill='#d6b779')
cover.save(PREVIEW/'royal-forge-hud-cover.jpg',quality=95)

receipt={
 'artifact':str(ZIP.name), 'pack_sha256':hashlib.sha256(ZIP.read_bytes()).hexdigest(),
 'collection_count':1,'manifest_count':1,'atlas_count':len(textures),'asset_count':len(assets),
 'kinds':dict(collections.Counter(a['kind'] for a in assets.values())),
 'source_regions_checked':len(regions),'state_sets_checked':len(states),'numeric_widgets_all_10_values':len(numeric),
 'sequences_checked':len(seqs),'errors':errors,'warnings':warnings,
 'checks':{'custom_dependency_and_geometry':'PASS' if not errors else 'FAIL',
           'custom_creator_specific_acceptance':'PASS' if not errors else 'FAIL',
           'custom_alpha_crops':'WARN' if warnings else 'PASS',
           'official_repo_validator':'NOT RUN','official_browser_render_matrix':'NOT RUN',
           'official_builder_export_reimport':'NOT RUN'},
 'interpretation':'Independent PIL preview approximates Canvas 2D; it is not the official browser renderer.'}
(QA/'creator-qa-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(QA/'numeric-pixel-results.json').write_text(json.dumps(test_log,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ['asset_count','kinds','numeric_widgets_all_10_values','errors','warnings']},indent=2)[:6000])
if errors:sys.exit(1)
