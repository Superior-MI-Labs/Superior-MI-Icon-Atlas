# Royal Forge — HUD Resource Systems Vol. 1

**Status:** Candidate, ready for creator preview. Not yet released to the public asset catalog.

## Runtime pack
`Royal-Forge-HUD-Resource-Systems-v1.1-Adaptive-Candidate.zip` — drop this ZIP into the Superior MI Visual Atlas Builder. Opens the Royal Health Bar by default.

## Art inventory
- 360 addressable assets
- 175 measured RGBA source regions in one 2048×2048 texture atlas
- 159 compositions (50 resource bars; 34 legacy four-heart value states; 42 legacy six-pip value states; 10 new adaptive indicator compositions; 6 orbs; 5 vials; 12 boss bars)
- 24 state sets (4 fractional single-heart families; 2 four-heart counters; 6 charge-meter families; 6 individual pip-state families; 6 radial families)
- 2 independent effect sequences, each four distinct illustrated frames
- 5 bar-shell styles: Royal, Runic, Iron, Verdant, Arcane
- 10 resource colors: Health, Mana, Stamina, Shield, Experience, Rage, Oxygen, Focus, Heat, Corruption
- Native value behaviors on all 73 numeric compositions, 0–100 range.

## Important semantics
- Hearts use exact quarter variants: 4 containers × 4 health per container = 0..16 health points. The selected `hp_00`..`hp_16` state changes the displayed hearts.
- Charge-meter family switches `charge_0`..`charge_6`; it is not a continuously clipped numeric bar.
- Radial meter family switches 11 baked angular states, `pct_000`..`pct_100` in increments of 10. A host selects the state. No unsupported circular `clip` API is invented.
- Continuous bars, orbs, boss bars and vials expose native `value` and `set_value` behavior events. Host software owns direct pointer/gamepad hit testing.

## QA and reproducibility
- Generate: `python source/build_resource_pack.py`
- Custom pixel/spec/contact QA: `python source/qualify_resources.py`
- Chromium: `python source/browser_canvas_qa.py` (requires Playwright and system Chromium)
- Acceptance: `qa/creator-acceptance.json` is compatible with the repo's `tools/ai_acceptance.py`.
- Official repo schema validator, repo's acceptance checker, repo's Builder smoke and export/reimport remain **NOT RUN**. These are publication blockers, not implied passes.
- 11 intentionally edge-touching liquid fill regions are documented in `source/PRODUCTION-LESSONS.md`.

## Repository gate (full checkout)
```
python tools/validate_visual_pack.py Royal-Forge-HUD-Resource-Systems-v1.1-Adaptive-Candidate.zip
python tools/qualify_asset_zip.py Royal-Forge-HUD-Resource-Systems-v1.1-Adaptive-Candidate.zip --out qa/resource-pack
python tools/ai_acceptance.py Royal-Forge-HUD-Resource-Systems-v1.1-Adaptive-Candidate.zip --acceptance qa/creator-acceptance.json --out qa/resource-acceptance
bash RUN-ALL.sh
```
Then open the ZIP in the local Builder, run the final scenario-specific Chromium visual matrix and export/reimport a tested resource asset to verify pixel equivalence. Only afterward request publication approval.

## Adaptive v1.1 changes
- 10 live compositions: 4 fractional-heart families and 6 whole charge-pip families. Max 1–20, value, columns 1–20. One repeat layer derives row count and actual size from the inputs.
- Both state dropdown and step-slider supported by shared viewer. v1.1 requires Visual Atlas renderer/schema feature PR #6.
- Base/rim SVG paths revised to remove continuous horizontal strokes crossing upper studs and runes.
- Original static counter IDs retained for compatibility.
- This is a creator candidate, NOT the public catalog.
