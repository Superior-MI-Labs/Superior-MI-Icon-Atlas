Procedural demo artwork. These images are original examples, not production art. CC0-1.0. https://creativecommons.org/publicdomain/zero/1.0/
