Canvas 512x256. Define explicit rect_px per region. Nine-slice margins derive from actual artwork geometry. Verify every UI state.
